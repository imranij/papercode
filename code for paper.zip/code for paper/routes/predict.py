from flask import Blueprint, render_template, request, redirect, url_for, flash
import pandas as pd
import os
import torch
import joblib
import numpy as np
import uuid
from datetime import datetime

from models.selector import select_top_configurations
from utils.preprocessing import preprocess_pzt, preprocess_tio3
from utils.metrics import evaluate_predictions
from utils.plot_generator import generate_pzt_plots, generate_tio3_plots
from utils.generators import save_csv_table
from models.pytorch_model import PZTNet, TiO3Net  # ← Now importing both

predict_bp = Blueprint('predict', __name__)

UPLOAD_FOLDER = 'data/uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

def detect_dataset_type(df):
    pzt_cols = {'ZnO', 'MgO', 'TIO3', 'Temp1', 'Time1', 'Temp2', 'Time2'}
    tio3_cols = {'TiO3', 'Ba', 'Bi', 'K', 'calcinationtemp', 'sinteringTemperature'}
    df_cols = set(df.columns)
    if pzt_cols.issubset(df_cols):
        return 'PZT'
    elif tio3_cols.issubset(df_cols):
        return 'TiO3'
    return None

@predict_bp.route('/', methods=['GET', 'POST'])
def predict():
    if request.method == 'POST':
        file = request.files.get('file')
        if not file:
            flash('No file uploaded.')
            return redirect(request.url)

        filepath = os.path.join(UPLOAD_FOLDER, file.filename)
        file.save(filepath)

        try:
            df = pd.read_csv(filepath)
        except Exception as e:
            flash(f'Error reading CSV: {e}')
            return redirect(request.url)

        run_id = str(uuid.uuid4())[:8]
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        dataset_type = detect_dataset_type(df)
        if dataset_type is None:
            flash("Dataset format not recognized.")
            return redirect(request.url)

        # Dataset-specific config
        if dataset_type == 'PZT':
            X_raw, y, input_cols, output_cols = preprocess_pzt(df)
            model = PZTNet()
            model_path = 'models/dnn_pzt.pt'
            scaler_path = 'models/scaler_pzt.pkl'
            generate_plots = generate_pzt_plots
            metrics_csv = f'{run_id}_pzt_model_metrics.csv'
            rec_csv = f'{run_id}_pzt_recommendations.csv'
        elif dataset_type == 'TiO3':
            X_raw, y, input_cols, output_cols = preprocess_tio3(df)
            model = TiO3Net()
            model_path = 'models/dnn_tio3.pt'
            scaler_path = 'models/scaler_tio3.pkl'
            generate_plots = generate_tio3_plots
            metrics_csv = f'{run_id}_tio3_model_metrics.csv'
            rec_csv = f'{run_id}_tio3_recommendations.csv'

        scaler = joblib.load(scaler_path)
        X_scaled = pd.DataFrame(scaler.transform(X_raw), columns=input_cols)

        model.load_state_dict(torch.load(model_path))
        model.eval()
        X_tensor = torch.tensor(X_scaled.values, dtype=torch.float32)
        with torch.no_grad():
            y_pred_tensor = model(X_tensor)
        y_pred = y_pred_tensor.numpy()

        # Save for downstream use
        X_scaled.to_csv(f"data/{run_id}_inputs.csv", index=False)
        pd.DataFrame(y_pred, columns=output_cols).to_csv(f"data/{run_id}_predictions.csv", index=False)
        if y is not None:
            y.to_csv(f"data/{run_id}_actuals.csv", index=False)

        # Recommendations
        recommendations = select_top_configurations(X_scaled, y_pred, input_cols, output_cols)
        if recommendations:
            rec_rows = []
            for rec in recommendations:
                row = {**rec["inputs"], **rec["predicted_outputs"]}
                row["Rank"] = rec["rank"]
                rec_rows.append(row)
            rec_df = pd.DataFrame(rec_rows)
            save_csv_table(rec_df, rec_csv)

        # Evaluation metrics
        metrics = evaluate_predictions(y_true=y, y_pred=y_pred, target_names=output_cols) if y is not None else None
        if metrics:
            save_csv_table(pd.DataFrame(metrics), metrics_csv)

        # Plot generation
        generate_plots(
            input_path=f"data/{run_id}_inputs.csv",
            pred_path=f"data/{run_id}_predictions.csv",
            true_path=f"data/{run_id}_actuals.csv"
        )

        return render_template('predict.html',
                               dataset_type=dataset_type,
                               run_id=run_id,
                               timestamp=timestamp,
                               columns=input_cols,
                               recommendations=recommendations,
                               metrics=metrics)

    return render_template('predict.html')
