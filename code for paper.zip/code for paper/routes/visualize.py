from flask import Blueprint, render_template, request, send_from_directory
import os

visualize_bp = Blueprint('visualize', __name__)
PLOTS_FOLDER = 'static/plots'

@visualize_bp.route('/', methods=['GET', 'POST'])
def visualize():
    # List only .png plots
    all_plots = [f for f in os.listdir(PLOTS_FOLDER) if f.endswith('.png')]

    # Group plots by run_id prefix
    grouped = {}
    for filename in all_plots:
        run_id = filename.split('_')[0] if '_' in filename else 'other'
        grouped.setdefault(run_id, []).append(filename)

    selected_plot = None
    selected_run = None

    if request.method == 'POST':
        selected_plot = request.form.get('plot_name')
        selected_run = request.form.get('run_id_filter')

    return render_template('visualize.html',
                           grouped_plots=grouped,
                           selected_plot=selected_plot,
                           selected_run=selected_run)

@visualize_bp.route('/download/<filename>')
def download_plot(filename):
    path = os.path.join(PLOTS_FOLDER, filename)
    if os.path.exists(path):
        return send_from_directory(PLOTS_FOLDER, filename, as_attachment=True)
    return f"Plot {filename} not found.", 404
