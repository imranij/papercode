from flask import Blueprint, render_template, request, send_file
import os
import pandas as pd

tables_bp = Blueprint('tables', __name__)
TABLES_FOLDER = 'static/paper_tables'

@tables_bp.route('/', methods=['GET', 'POST'])
def tables():
    available_tables = [f for f in os.listdir(TABLES_FOLDER) if f.endswith('.csv')]

    selected_table = None
    table_data = None

    if request.method == 'POST':
        selected_table = request.form.get('table_name')
        if selected_table:
            csv_path = os.path.join(TABLES_FOLDER, selected_table)
            try:
                table_data = pd.read_csv(csv_path)
            except Exception as e:
                table_data = pd.DataFrame({'Error': [str(e)]})

    return render_template('tables.html',
                           available_tables=available_tables,
                           selected_table=selected_table,
                           table_data=table_data)

@tables_bp.route('/download/<filename>')
def download_table(filename):
    file_path = os.path.join(TABLES_FOLDER, filename)
    if os.path.exists(file_path):
        return send_file(file_path, as_attachment=True)
    return f"File {filename} not found.", 404
