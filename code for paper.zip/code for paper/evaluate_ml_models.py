import os
import pandas as pd
import numpy as np
from sklearn.multioutput import MultiOutputRegressor
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_percentage_error

from sklearn.linear_model import LinearRegression, Ridge, Lasso
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor

# === Paths ===
DATA_DIR = "data"
OUTPUT_CSV = os.path.join(DATA_DIR, "traditional_model_summary.csv")

# === Metrics ===
def rmse(y_true, y_pred):
    return np.sqrt(mean_squared_error(y_true, y_pred))

def evaluate(y_true, y_pred, output_cols):
    results = {}
    for i, col in enumerate(output_cols):
        results[f"RMSE_{col}"] = rmse(y_true[:, i], y_pred[:, i])
        results[f"R2_{col}"] = r2_score(y_true[:, i], y_pred[:, i])
        results[f"MAPE_{col}"] = mean_absolute_percentage_error(y_true[:, i], y_pred[:, i])
    return results

# === Model Set ===


MODELS = {
    "LinearRegression": LinearRegression(),
    "Ridge": Ridge(),
    "Lasso": Lasso(),
    "DecisionTree": MultiOutputRegressor(DecisionTreeRegressor()),
    "RandomForest": MultiOutputRegressor(RandomForestRegressor()),
    "GradientBoosting": MultiOutputRegressor(GradientBoostingRegressor())
}


# === Dataset Definitions ===
DATASETS = {
    "pzt": {
        "input_cols": ['ZnO', 'MgO', 'TIO3', 'Temp1', 'Time1', 'Temp2', 'Time2'],
        "output_cols": ['SinteredDensity', 'DielectricConstant', 'QualityFactor']
    },
    "tio3": {
        "input_cols": ['TiO3', 'Ba', 'Bi', 'K', 'calcinationtemp', 'calcinationtime', 'sinteringTemperature', 'sinteringtime'],
        "output_cols": ['ElectricalResistivity', 'TemperatureCoefficientOfResistivity', 'CurieTemperature', 'DielectricConstant']
    }
}

# === Main Evaluation ===
summary = []

for ds_name, config in DATASETS.items():
    df = pd.read_csv(os.path.join(DATA_DIR, f"sample_{ds_name}.csv"))

    X = df[config["input_cols"]].values
    y = df[config["output_cols"]].values

    scaler = MinMaxScaler()
    X_scaled = scaler.fit_transform(X)

    X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

    for model_name, model in MODELS.items():
        model.fit(X_train, y_train)
        y_pred = model.predict(X_test)
        metrics = evaluate(y_test, y_pred, config["output_cols"])
        summary.append({
            "Dataset": ds_name.upper(),
            "Model": model_name,
            **metrics
        })

# === Save Summary ===
df_summary = pd.DataFrame(summary)
df_summary.to_csv(OUTPUT_CSV, index=False)
print(f"✅ Saved model comparison summary to: {OUTPUT_CSV}")
