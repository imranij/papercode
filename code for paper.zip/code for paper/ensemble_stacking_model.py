import os
import pandas as pd
import numpy as np
from sklearn.neural_network import MLPRegressor
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_percentage_error
import subprocess

DATA_DIR = "data"

# === Metrics ===
def rmse(y_true, y_pred):
    return np.sqrt(mean_squared_error(y_true, y_pred))

def evaluate(y_true, y_pred):
    results = {}
    if isinstance(y_true, pd.DataFrame):
        columns = y_true.columns
        y_true = y_true.values
        y_pred = y_pred.values
    else:
        columns = [f"Target_{i}" for i in range(y_true.shape[1])]

    for i, name in enumerate(columns):
        results[f"RMSE_{name}"] = rmse(y_true[:, i], y_pred[:, i])
        results[f"R2_{name}"] = r2_score(y_true[:, i], y_pred[:, i])
        results[f"MAPE_{name}"] = mean_absolute_percentage_error(y_true[:, i], y_pred[:, i])
    return results

def infer_target_columns(dataset_name):
    if dataset_name == "pzt":
        return ["SinteredDensity", "DielectricConstant", "QualityFactor"]
    elif dataset_name == "tio3":
        return ["ElectricalResistivity", "TemperatureCoefficientOfResistivity", "CurieTemperature", "DielectricConstant"]
    return []

# === Train v1 and v2 base models and capture their predictions
def train_model_version(dataset, version):
    prefix = f"sample_{dataset}" + ("_v2" if version == "v2" else "")
    script = f"train_{dataset}_model" + ("_v2" if version == "v2" else "") + ".py"
    input_file = os.path.join(DATA_DIR, f"sample_{dataset}.csv")

    result = subprocess.run([
        "python", script,
        "--input_file", input_file,
        "--prefix", prefix
    ], capture_output=True, text=True)

    pred_path = os.path.join(DATA_DIR, f"{prefix}_predictions.csv")
    actual_path = os.path.join(DATA_DIR, f"{prefix}_actuals.csv")
    return pred_path, actual_path

# === Main stacking routine
def train_stacked_ensemble(dataset):
    print(f"\n📦 Light stacking ensemble for: {dataset.upper()}")

    # Get predictions from v1 and v2 models
    pred_v1, actual_path = train_model_version(dataset, "v1")
    pred_v2, _ = train_model_version(dataset, "v2")

    preds_v1 = pd.read_csv(pred_v1)
    preds_v2 = pd.read_csv(pred_v2)
    actuals = pd.read_csv(actual_path)

    targets = infer_target_columns(dataset)
    preds_v1 = preds_v1[targets]
    preds_v2 = preds_v2[targets]
    actuals = actuals[targets]

    # Meta-features for stacking
    meta_X = pd.concat([preds_v1.add_suffix("_v1"), preds_v2.add_suffix("_v2")], axis=1)
    meta_preds = pd.DataFrame(index=actuals.index, columns=targets)

    # Train one MLPRegressor per target
    for target in targets:
        X_stack = meta_X[[f"{target}_v1", f"{target}_v2"]]
        y_stack = actuals[target]

        model = MLPRegressor(hidden_layer_sizes=(16,), max_iter=500, random_state=42)
        model.fit(X_stack, y_stack)
        y_pred = model.predict(X_stack)
        meta_preds[target] = y_pred

    # Save predictions and actuals
    pred_path = os.path.join(DATA_DIR, f"stacked_v12_{dataset}_predictions_v1v2.csv")
    actual_path = os.path.join(DATA_DIR, f"stacked_v12_{dataset}_actuals_v1v2.csv")
    meta_preds.to_csv(pred_path, index=False)
    actuals.to_csv(actual_path, index=False)
    print(f"📁 Saved predictions to {pred_path}")
    print(f"📁 Saved actuals to {actual_path}")

    return evaluate(actuals, meta_preds)

# === Run for all datasets
if __name__ == "__main__":
    summary = []
    for ds in ["pzt", "tio3"]:
        metrics = train_stacked_ensemble(ds)
        summary.append({"Dataset": ds.upper(), "Model": "stacked-mlp-v1v2", **metrics})

    df_summary = pd.DataFrame(summary)
    out_path = os.path.join(DATA_DIR, "ensemble_stacking_v1v2_summary.csv")
    df_summary.to_csv(out_path, index=False)
    print(f"\n✅ Light ensemble summary saved to {out_path}")
