import os

# Base directories
BASE_DIR = os.path.abspath(os.path.dirname(__file__))

# Uploads
UPLOAD_FOLDER = os.path.join(BASE_DIR, 'data', 'uploads')
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Static assets
PLOTS_FOLDER = os.path.join(BASE_DIR, 'static', 'plots')
TABLES_FOLDER = os.path.join(BASE_DIR, 'static', 'paper_tables')

# Model paths
MODEL_PZT_PATH = os.path.join(BASE_DIR, 'models', 'dnn_pzt.h5')
MODEL_TIO3_PATH = os.path.join(BASE_DIR, 'models', 'dnn_tio3.h5')

# Prediction selector config
TOP_K_RECOMMENDATIONS = 3

# Allowed extensions for uploads
ALLOWED_EXTENSIONS = {'csv'}

# Flask secret key (for flash messages etc.)
SECRET_KEY = 'your-secret-key-here'
