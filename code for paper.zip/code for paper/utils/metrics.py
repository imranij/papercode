from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_percentage_error
import pandas as pd
import numpy as np

def evaluate_predictions(y_true, y_pred, target_names=None):
    """
    Computes RMSE, MSE, R², and MAPE for each output column.

    Parameters:
        y_true (pd.DataFrame or np.ndarray): Ground truth output values
        y_pred (np.ndarray): Predicted output values
        target_names (list): Column names for the outputs

    Returns:
        List of dictionaries containing metric results per target
    """
    if target_names is None:
        target_names = [f"Target_{i}" for i in range(y_true.shape[1])]

    results = []

    for i, target in enumerate(target_names):
        actual = y_true[:, i] if isinstance(y_true, np.ndarray) else y_true.iloc[:, i].values
        predicted = y_pred[:, i]

        mse = mean_squared_error(actual, predicted)
        rmse = mse ** 0.5
        r2 = r2_score(actual, predicted)
        mape = mean_absolute_percentage_error(actual, predicted) * 100

        results.append({
            "target": target,
            "RMSE": round(rmse, 4),
            "MSE": round(mse, 4),
            "R2": round(r2, 4),
            "MAPE (%)": round(mape, 2)
        })

    return results
