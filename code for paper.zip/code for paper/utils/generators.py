import pandas as pd
import os

def save_csv_table(df, filename, folder='static/paper_tables'):
    """
    Save a DataFrame as CSV in the specified folder.

    Parameters:
        df (pd.DataFrame): DataFrame to save
        filename (str): Output filename (e.g., "summary_results.csv")
        folder (str): Directory path to save into
    """
    os.makedirs(folder, exist_ok=True)
    filepath = os.path.join(folder, filename)
    df.to_csv(filepath, index=False)
    return filepath

def save_latex_table(df, filename, folder='static/paper_tables'):
    """
    Save a DataFrame as LaTeX table in the specified folder.

    Parameters:
        df (pd.DataFrame): DataFrame to save
        filename (str): Output filename (e.g., "summary_results.tex")
        folder (str): Directory path to save into
    """
    os.makedirs(folder, exist_ok=True)
    filepath = os.path.join(folder, filename)
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(df.to_latex(index=False, escape=True))
    return filepath
