import os
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.metrics import mean_squared_error

def generate_pzt_plots(input_path, pred_path, true_path=None, output_dir='static/plots'):
    _generate_plots(
        dataset="PZT",
        pred_path=pred_path,
        true_path=true_path,
        output_dir=output_dir
    )

def generate_tio3_plots(input_path, pred_path, true_path=None, output_dir='static/plots'):
    _generate_plots(
        dataset="TiO3",
        pred_path=pred_path,
        true_path=true_path,
        output_dir=output_dir
    )

def _generate_plots(dataset, pred_path, true_path=None, output_dir='static/plots'):
    os.makedirs(output_dir, exist_ok=True)

    y_pred = pd.read_csv(pred_path)
    output_cols = y_pred.columns.tolist()
    y_pred_vals = y_pred.values

    y_true_vals = pd.read_csv(true_path).values if true_path and os.path.exists(true_path) else None

    # Predicted vs Actual or Index vs Predicted
    for i, label in enumerate(output_cols):
        plt.figure(figsize=(6, 5))
        if y_true_vals is not None:
            plt.scatter(y_true_vals[:, i], y_pred_vals[:, i], color='blue', edgecolor='k')
            plt.plot([y_true_vals[:, i].min(), y_true_vals[:, i].max()],
                     [y_true_vals[:, i].min(), y_true_vals[:, i].max()],
                     'r--', label='Ideal')
            plt.xlabel("Actual")
        else:
            plt.scatter(range(len(y_pred_vals)), y_pred_vals[:, i], color='blue', edgecolor='k')
            plt.xlabel("Sample Index")

        plt.ylabel("Predicted")
        plt.title(f"{dataset}: {label} Prediction")
        plt.legend()
        plt.tight_layout()
        plot_name = f"{dataset.lower()}_{label.lower().replace(' ', '_')}.png"
        plt.savefig(os.path.join(output_dir, plot_name))
        plt.close()

    # RMSE Plot
    if y_true_vals is not None:
        rmse_scores = [
            mean_squared_error(y_true_vals[:, i], y_pred_vals[:, i]) ** 0.5
            for i in range(len(output_cols))
        ]
        plt.figure(figsize=(6, 5))
        plt.bar(output_cols, rmse_scores, color='skyblue', edgecolor='black')
        plt.title(f"{dataset} RMSE by Output Variable")
        plt.ylabel("RMSE")
        plt.tight_layout()
        plt.savefig(os.path.join(output_dir, f"{dataset.lower()}_rmse_summary.png"))
        plt.close()

    print(f"✅ Generated {dataset} paper plots in {output_dir}")
