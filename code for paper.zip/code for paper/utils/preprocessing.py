import pandas as pd
from sklearn.preprocessing import MinMaxScaler

def preprocess_pzt(df):
    input_cols = ['ZnO', 'MgO', 'TIO3', 'Temp1', 'Time1', 'Temp2', 'Time2']
    output_cols = ['SinteredDensity', 'DielectricConstant', 'QualityFactor']

    df = df.drop(columns=['ID'], errors='ignore')
    df = df.fillna(df.mean(numeric_only=True))

    X = df[input_cols].copy()
    y = df[output_cols].copy() if all(col in df.columns for col in output_cols) else None

    return X, y, input_cols, output_cols

def preprocess_tio3(df):
    input_cols = ['TiO3', 'Ba', 'Bi', 'K', 'calcinationtemp', 'calcinationtime',
                  'sinteringTemperature', 'sinteringtime']
    output_cols = ['ElectricalResistivity', 'TemperatureCoefficientOfResistivity',
                   'CurieTemperature', 'DielectricConstant']

    df = df.fillna(df.mean(numeric_only=True))

    X = df[input_cols].copy()
    y = df[output_cols].copy() if all(col in df.columns for col in output_cols) else None

    scaler = MinMaxScaler()
    X_scaled = pd.DataFrame(scaler.fit_transform(X), columns=input_cols)

    return X_scaled, y, input_cols, output_cols

