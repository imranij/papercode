import os
import pandas as pd
import numpy as np
from sklearn.neural_network import MLPRegressor
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_percentage_error
import subprocess

DATA_DIR = "data"

# === Metrics ===
def rmse(y_true, y_pred):
    return np.sqrt(mean_squared_error(y_true, y_pred))

def evaluate(y_true, y_pred):
    results = {}
    if isinstance(y_true, pd.DataFrame):
        columns = y_true.columns
        y_true = y_true.values
        y_pred = y_pred.values
    else:
        columns = [f"Target_{i}" for i in range(y_true.shape[1])]

    for i, name in enumerate(columns):
        results[f"RMSE_{name}"] = rmse(y_true[:, i], y_pred[:, i])
        results[f"R2_{name}"] = r2_score(y_true[:, i], y_pred[:, i])
        results[f"MAPE_{name}"] = mean_absolute_percentage_error(y_true[:, i], y_pred[:, i])
    return results

def infer_target_columns(dataset_name):
    if dataset_name == "pzt":
        return ["SinteredDensity", "DielectricConstant", "QualityFactor"]
    elif dataset_name == "tio3":
        return ["ElectricalResistivity", "TemperatureCoefficientOfResistivity", "CurieTemperature", "DielectricConstant"]
    return []

# === Train a specific model version and return predictions
def train_model_version(dataset, version):
    suffix = "" if version == "v1" else f"_{version}"
    script = f"train_{dataset}_model{suffix}.py"
    prefix = f"sample_{dataset}{suffix}"
    input_file = os.path.join(DATA_DIR, f"sample_{dataset}.csv")

    result = subprocess.run([
        "python", script,
        "--input_file", input_file,
        "--prefix", prefix
    ], capture_output=True, text=True)

    pred_path = os.path.join(DATA_DIR, f"{prefix}_predictions.csv")
    actual_path = os.path.join(DATA_DIR, f"{prefix}_actuals.csv")
    return pred_path, actual_path

# === Main stacking routine (v1 + v2 + v3)
def train_stacked_ensemble(dataset):
    print(f"\n📦 Full stacking ensemble for: {dataset.upper()}")

    # Run and collect predictions
    pred_v1, actual_path = train_model_version(dataset, "v1")
    pred_v2, _ = train_model_version(dataset, "v2")
    pred_v3, _ = train_model_version(dataset, "v3")

    preds_v1 = pd.read_csv(pred_v1)
    preds_v2 = pd.read_csv(pred_v2)
    preds_v3 = pd.read_csv(pred_v3)
    actuals = pd.read_csv(actual_path)

    targets = infer_target_columns(dataset)

    # Rename prediction columns
    preds_v1.columns = [f"{col}_v1" for col in targets]
    preds_v2.columns = [f"{col}_v2" for col in targets]
    preds_v3.columns = [f"{col}_v3" for col in targets]
    actuals.columns = targets

    # Stack inputs
    meta_X = pd.concat([preds_v1, preds_v2, preds_v3], axis=1)
    meta_preds = pd.DataFrame(index=actuals.index, columns=targets)

    # Train ensemble model per target
    for target in targets:
        X_stack = meta_X[[f"{target}_v1", f"{target}_v2", f"{target}_v3"]]
        y_stack = actuals[target]

        model = MLPRegressor(hidden_layer_sizes=(16,), max_iter=500, random_state=42)
        model.fit(X_stack, y_stack)
        y_pred = model.predict(X_stack)
        meta_preds[target] = y_pred

    # Save predicted and actual values
    pred_path = os.path.join(DATA_DIR, f"stacked_v123_{dataset}_predictions_v2.csv")
    actual_path = os.path.join(DATA_DIR, f"stacked_v123_{dataset}_actuals_v2.csv")
    meta_preds.to_csv(pred_path, index=False)
    actuals.to_csv(actual_path, index=False)
    print(f"📁 Saved predictions to {pred_path}")
    print(f"📁 Saved actuals to {actual_path}")

    return evaluate(actuals, meta_preds)

# === Run for both datasets
if __name__ == "__main__":
    summary = []
    for ds in ["pzt", "tio3"]:
        metrics = train_stacked_ensemble(ds)
        summary.append({"Dataset": ds.upper(), "Model": "stacked-mlp-v2", **metrics})

    df_summary = pd.DataFrame(summary)
    out_path = os.path.join(DATA_DIR, "ensemble_stacking_v2_summary.csv")
    df_summary.to_csv(out_path, index=False)
    print(f"\n✅ Ensemble v2 summary saved to {out_path}")
