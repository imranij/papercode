import pandas as pd
import numpy as np
import torch
import torch.nn as nn
import argparse
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler, StandardScaler
import joblib
import os

# === CLI Arguments ===
parser = argparse.ArgumentParser()
parser.add_argument('--input_file', type=str, required=True)
parser.add_argument('--prefix', type=str, required=True)
args = parser.parse_args()

# === Load and preprocess dataset ===
df = pd.read_csv(args.input_file)
input_cols = ['ZnO', 'MgO', 'TIO3', 'Temp1', 'Time1', 'Temp2', 'Time2']
output_cols = ['SinteredDensity', 'DielectricConstant', 'QualityFactor']

X = df[input_cols]
y = df[output_cols]

# Scale input
x_scaler = MinMaxScaler()
X_scaled = x_scaler.fit_transform(X)

# Standardize targets
y_scaler = StandardScaler()
y_scaled = y_scaler.fit_transform(y)

# Save scalers
os.makedirs("models", exist_ok=True)
joblib.dump(x_scaler, f"models/scaler_X_{args.prefix}.pkl")
joblib.dump(y_scaler, f"models/scaler_y_{args.prefix}.pkl")

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y_scaled, test_size=0.2, random_state=42)
X_train = torch.tensor(X_train, dtype=torch.float32)
y_train = torch.tensor(y_train, dtype=torch.float32)
X_test = torch.tensor(X_test, dtype=torch.float32)
y_test = torch.tensor(y_test, dtype=torch.float32)

# === Multi-head Neural Net ===
class PZTNetV3(nn.Module):
    def __init__(self):
        super().__init__()
        self.shared = nn.Sequential(
            nn.Linear(7, 128),
            nn.BatchNorm1d(128),
            nn.ReLU(),
            nn.Dropout(0.25),
            nn.Linear(128, 64),
            nn.ReLU()
        )
        self.heads = nn.ModuleList([nn.Linear(64, 1) for _ in range(3)])

    def forward(self, x):
        x = self.shared(x)
        return torch.cat([head(x) for head in self.heads], dim=1)

model = PZTNetV3()
optimizer = torch.optim.AdamW(model.parameters(), lr=0.001)
criterion = nn.MSELoss()

# === Training Loop with Early Stopping ===
best_loss = np.inf
patience = 100
wait = 0

for epoch in range(1000):
    model.train()
    optimizer.zero_grad()
    out = model(X_train)
    loss = criterion(out, y_train)
    loss.backward()
    optimizer.step()

    if epoch % 50 == 0:
        print(f"Epoch {epoch} | Loss: {loss.item():.6f}")

    # Early stopping
    if loss.item() < best_loss - 1e-5:
        best_loss = loss.item()
        wait = 0
        torch.save(model.state_dict(), f"models/{args.prefix}_model.pt")
    else:
        wait += 1
        if wait >= patience:
            print(f"[INFO] Early stopping at epoch {epoch}")
            break

# === Prediction and Saving Outputs ===
model.load_state_dict(torch.load(f"models/{args.prefix}_model.pt"))
model.eval()
with torch.no_grad():
    preds = model(X_test).numpy()

# Inverse transform predictions and targets
preds_orig = y_scaler.inverse_transform(preds)
y_test_orig = y_scaler.inverse_transform(y_test.numpy())

# Save results
os.makedirs("data", exist_ok=True)
pred_path = f"data/{args.prefix}_predictions.csv"
act_path = f"data/{args.prefix}_actuals.csv"

pd.DataFrame(preds_orig, columns=output_cols).to_csv(pred_path, index=False)
pd.DataFrame(y_test_orig, columns=output_cols).to_csv(act_path, index=False)

print(f"[✅] Saved predictions to {pred_path}")
print(f"[✅] Saved actuals to {act_path}")
