import os
import pandas as pd
import numpy as np
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_percentage_error

# === Paths ===
DATA_DIR = "data"
OUTPUT_CSV = os.path.join(DATA_DIR, "deep_model_v3_summary.csv")

# === Metrics === 
#for runing the models first
# python train_pzt_model_v3.py --input_file data/sample_pzt.csv --prefix pzt_v3
# python train_tio3_model_v3.py --input_file data/sample_tio3.csv --prefix tio3_v3

def rmse(y_true, y_pred):
    return np.sqrt(mean_squared_error(y_true, y_pred))

def evaluate(y_true, y_pred, output_cols):
    results = {}
    for i, col in enumerate(output_cols):
        results[f"RMSE_{col}"] = rmse(y_true[:, i], y_pred[:, i])
        results[f"R2_{col}"] = r2_score(y_true[:, i], y_pred[:, i])
        results[f"MAPE_{col}"] = mean_absolute_percentage_error(y_true[:, i], y_pred[:, i])
    return results

# === Dataset Config ===
DATASETS = {
    "pzt": {
        "output_cols": ['SinteredDensity', 'DielectricConstant', 'QualityFactor']
    },
    "tio3": {
        "output_cols": ['ElectricalResistivity', 'TemperatureCoefficientOfResistivity', 'CurieTemperature', 'DielectricConstant']
    }
}

# === Evaluation Loop ===
summary = []

for ds_name, config in DATASETS.items():
    prefix = f"{ds_name}_v3"
    pred_file = os.path.join(DATA_DIR, f"{prefix}_predictions.csv")
    act_file = os.path.join(DATA_DIR, f"{prefix}_actuals.csv")

    if not (os.path.exists(pred_file) and os.path.exists(act_file)):
        print(f"❌ Missing files for {ds_name.upper()} V3")
        continue

    preds = pd.read_csv(pred_file)
    actuals = pd.read_csv(act_file)

    metrics = evaluate(actuals.values, preds.values, config["output_cols"])
    summary.append({
        "Dataset": ds_name.upper(),
        "Model": "DeepV3",
        **metrics
    })

# === Save Summary ===
df_summary = pd.DataFrame(summary)
df_summary.to_csv(OUTPUT_CSV, index=False)
print(f"\n✅ Saved V3 deep learning summary to: {OUTPUT_CSV}")
