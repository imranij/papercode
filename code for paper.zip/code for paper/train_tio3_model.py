import pandas as pd
import numpy as np
import torch
import torch.nn as nn
import argparse
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler
import joblib
import os

# === CLI Arguments ===
parser = argparse.ArgumentParser()
parser.add_argument('--input_file', type=str, required=True, help='Path to input CSV dataset')
parser.add_argument('--prefix', type=str, required=True, help='Prefix for saving model and prediction files')
args = parser.parse_args()

# === Load and preprocess dataset ===
df = pd.read_csv(args.input_file)
input_cols = ['TiO3', 'Ba', 'Bi', 'K', 'calcinationtemp', 'calcinationtime', 'sinteringTemperature', 'sinteringtime']
output_cols = ['ElectricalResistivity', 'TemperatureCoefficientOfResistivity', 'CurieTemperature', 'DielectricConstant']

X = df[input_cols]
y = df[output_cols]

# Normalize inputs
scaler = MinMaxScaler()
X_scaled = scaler.fit_transform(X)

# Save the scaler
os.makedirs("models", exist_ok=True)
joblib.dump(scaler, f"models/scaler_tio3.pkl")

X_train, X_test, y_train, y_test = train_test_split(X_scaled, y.values, test_size=0.2, random_state=42)

X_train = torch.tensor(X_train, dtype=torch.float32)
y_train = torch.tensor(y_train, dtype=torch.float32)
X_test = torch.tensor(X_test, dtype=torch.float32)
y_test = torch.tensor(y_test, dtype=torch.float32)

# Define model
class TiO3Net(nn.Module):
    def __init__(self):
        super(TiO3Net, self).__init__()
        self.fc = nn.Sequential(
            nn.Linear(8, 64),
            nn.ReLU(),
            nn.Linear(64, 128),
            nn.ReLU(),
            nn.Linear(128, 64),
            nn.ReLU(),
            nn.Linear(64, 4)
        )

    def forward(self, x):
        return self.fc(x)

model = TiO3Net()
optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
criterion = nn.MSELoss()

# Train
for epoch in range(2000):
    model.train()
    optimizer.zero_grad()
    outputs = model(X_train)
    loss = criterion(outputs, y_train)
    loss.backward()
    optimizer.step()
    if epoch % 50 == 0:
        print(f"Epoch {epoch}, Loss: {loss.item():.4f}")

# Save model
model_path = f"models/{args.prefix}_model.pt"
torch.save(model.state_dict(), model_path)

# Predict
model.eval()
with torch.no_grad():
    predictions = model(X_test).numpy()

# Save predictions and actuals
pred_path = f"data/{args.prefix}_predictions.csv"
act_path = f"data/{args.prefix}_actuals.csv"
print(f"[INFO] Saving outputs with prefix: {args.prefix}")
try:
    pd.DataFrame(predictions, columns=output_cols).to_csv(pred_path, index=False)
    pd.DataFrame(y_test.numpy(), columns=output_cols).to_csv(act_path, index=False)

    assert os.path.exists(pred_path), f"[ERROR] Failed to save predictions to {pred_path}"
    assert os.path.exists(act_path), f"[ERROR] Failed to save actuals to {act_path}"

    print(f"[INFO] Files saved successfully: {pred_path}, {act_path}")

except Exception as e:
    print(f"[ERROR] Could not save prediction files: {e}")
