import os
import pandas as pd
import numpy as np
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_percentage_error
from sklearn.model_selection import train_test_split
from imblearn.over_sampling import SMOTE
import subprocess
import uuid
import re

# === Paths ===
DATA_DIR = "data"
MODEL_DIR = "models"
AUG_DIR = os.path.join(DATA_DIR, "augmented")
os.makedirs(AUG_DIR, exist_ok=True)

# === Metrics ===
def rmse(y_true, y_pred):
    return np.sqrt(mean_squared_error(y_true, y_pred))

def evaluate(y_true, y_pred):
    results = {}
    if isinstance(y_true, pd.DataFrame):
        columns = y_true.columns
        y_true = y_true.values
        y_pred = y_pred.values
    else:
        columns = [f"Target_{i}" for i in range(y_true.shape[1])]

    for i, name in enumerate(columns):
        results[f"RMSE_{name}"] = rmse(y_true[:, i], y_pred[:, i])
        results[f"R2_{name}"] = r2_score(y_true[:, i], y_pred[:, i])
        results[f"MAPE_{name}"] = mean_absolute_percentage_error(y_true[:, i], y_pred[:, i])
    return results

# === Augmentation Methods ===
def add_noise(df, level=0.05, n_copies=5, protected_cols=None):
    if protected_cols is None:
        protected_cols = ["TiO3", "sinteringTemperature", "Ba", "Bi"]
    augmented = []
    for _ in range(n_copies):
        noisy = df.copy()
        for col in noisy.select_dtypes(include=[np.number]).columns:
            if col in protected_cols:
                continue
            std = noisy[col].std()
            noise = np.random.normal(0, level * std, size=len(noisy))
            noisy[col] += noise
        augmented.append(noisy)
    return pd.concat(augmented, ignore_index=True)



def partial_shuffle(df, fraction=0.3, n_copies=5):
    augmented = []
    for _ in range(n_copies):
        shuffled = df.copy()
        n = int(fraction * len(df))
        indices = np.random.choice(df.index, n, replace=False)
        for col in df.columns:
            shuffled.loc[indices, col] = np.random.permutation(df.loc[indices, col].values)
        augmented.append(shuffled)
    return pd.concat(augmented, ignore_index=True)

def apply_smote(X, y):
    if len(X) < 6:
        return None, None
    try:
        sm = SMOTE()
        X_res, y_res = sm.fit_resample(X, y)
        return pd.DataFrame(X_res, columns=X.columns), pd.DataFrame(y_res, columns=y.columns)
    except Exception:
        return None, None

# === Helpers ===
def infer_target_columns(df, dataset_name):
    if dataset_name == "pzt":
        return ["SinteredDensity", "DielectricConstant", "QualityFactor"]
    elif dataset_name == "tio3":
        return ["ElectricalResistivity", "TemperatureCoefficientOfResistivity", "CurieTemperature", "DielectricConstant"]
    else:
        return df.columns[-1:]

def clean_data(df):
    df = df.drop(columns=[col for col in df.columns if "Unnamed" in col or col == "ID"], errors="ignore")
    return df

def split_X_y(df, target_cols):
    X = df.drop(columns=target_cols)
    y = df[target_cols]
    return X, y

# === Augmentation Generator ===
def generate_augmented_datasets():
    def generate_pzt_sample(n=3000, seed=42):
        np.random.seed(seed)
        df = pd.DataFrame({
            "ZnO": np.random.uniform(0.1, 1.0, n),
            "MgO": np.random.uniform(0.1, 1.0, n),
            "TIO3": np.random.randint(1, 3, n),
            "Temp1": np.random.randint(600, 800, n),
            "Time1": np.random.randint(1, 5, n),
            "Temp2": np.random.randint(900, 1100, n),
            "Time2": np.random.randint(2, 6, n),
        })

        # Improved formulas with stronger correlations and wider ranges
        df["SinteredDensity"] = (
            2.0 + 1.0 * df["ZnO"] + 0.8 * df["MgO"] + 0.005 * df["Temp2"] + 0.1 * df["Time2"]
        )
        df["DielectricConstant"] = (
            10 + 30 * df["ZnO"] * df["MgO"] + 0.025 * df["Temp1"] + 0.05 * df["Time1"]
        )
        df["QualityFactor"] = (
            3000 + 1200 * df["ZnO"] + 1000 * df["MgO"] +
            2.5 * df["Temp2"] + 15 * df["Time2"] + np.random.normal(0, 20, n)
        )

        return df


    def generate_tio3_sample(n=3000, seed=123):
        np.random.seed(seed)
        df = pd.DataFrame({
            "TiO3": np.random.uniform(0.95, 1.0, n),
            "Ba": np.random.uniform(0.01, 0.15, n),  # widened range
            "Bi": np.random.uniform(0.001, 0.04, n),  # widened range
            "K": np.random.uniform(0.001, 0.02, n),
            "calcinationtemp": np.random.randint(800, 1000, n),
            "calcinationtime": np.random.uniform(1.0, 2.0, n),
            "sinteringTemperature": np.random.randint(1300, 1500, n),
            "sinteringtime": np.random.uniform(1.0, 2.5, n),
        })

        # Improved signal strength and variance for all targets
        df["ElectricalResistivity"] = (
            0.1 + 10.0 * df["Ba"] + 0.004 * df["calcinationtemp"]
        )

        df["TemperatureCoefficientOfResistivity"] = (
            0.15 + 10.0 * df["Bi"] + 1.0 * df["sinteringtime"]
        )

        df["CurieTemperature"] = (
            400 + 800 * df["K"] + 50 * df["calcinationtime"] + np.random.normal(0, 5, n)
        )

        df["DielectricConstant"] = (
            100 + 80 * df["TiO3"] + 5 * df["Bi"] + 0.02 * df["sinteringTemperature"]
        )

        return df




    for ds in ["pzt", "tio3"]:
        if ds == "pzt":
            df_raw = generate_pzt_sample()
        else:
            df_raw = generate_tio3_sample()

        df_raw = clean_data(df_raw)
        target_cols = infer_target_columns(df_raw, ds)

        df_raw.to_csv(os.path.join(DATA_DIR, f"sample_{ds}.csv"), index=False)
        df_raw.to_csv(os.path.join(AUG_DIR, f"{ds}_original_ds.csv"), index=False)

        df_noise = add_noise(df_raw, level=0.05, n_copies=5)
        df_noise.to_csv(os.path.join(AUG_DIR, f"{ds}_noise_ds.csv"), index=False)

        df_shuf = partial_shuffle(df_raw, fraction=0.3, n_copies=5)
        df_shuf.to_csv(os.path.join(AUG_DIR, f"{ds}_shuffle_ds.csv"), index=False)

        X, y = split_X_y(df_raw, target_cols)
        X_res, y_res = apply_smote(X, y)
        if X_res is not None:
            df_smote = pd.concat([X_res, y_res], axis=1)
            df_smote.to_csv(os.path.join(AUG_DIR, f"{ds}_smote_ds.csv"), index=False)

# === Main Evaluation Loop ===
def run_all(dataset_name):
    methods = ["original", "noise", "shuffle", "smote"]
    results = []

    for method in methods:
        aug_file = os.path.join(AUG_DIR, f"{dataset_name}_{method}_ds.csv")
        if not os.path.exists(aug_file):
            continue
        res = train_and_eval(dataset_name, aug_file)
        results.append((method, res, aug_file))

    best = sorted(results, key=lambda x: list(x[1].values())[0])[0]  # Sort by first RMSE
    print(f"\n✅ Best for {dataset_name.upper()}: {best[0].upper()} | RMSE={list(best[1].values())[0]:.4f}")
    return best, results

# === Training Wrapper ===
def train_and_eval(dataset_name, augmented_file):
    prefix = os.path.splitext(os.path.basename(augmented_file))[0].replace("_ds", "")
    result = subprocess.run([
        "python", f"train_{dataset_name}_model.py",
        "--input_file", augmented_file,
        "--prefix", prefix
    ], capture_output=True, text=True)

    pred_path = os.path.join(DATA_DIR, f"{prefix}_predictions.csv")
    act_path = os.path.join(DATA_DIR, f"{prefix}_actuals.csv")

    if not os.path.exists(pred_path) or not os.path.exists(act_path):
        print("[ERROR] Prediction or actuals file not found for:", prefix)
        print("Expected files:", pred_path, act_path)
        print(result.stdout)
        print(result.stderr)
        raise FileNotFoundError(f"Missing output for prefix {prefix}")

    preds = pd.read_csv(pred_path)
    actuals = pd.read_csv(act_path)
    return evaluate(actuals, preds)

if __name__ == "__main__":
    generate_augmented_datasets()

    summary = []
    for ds in ["pzt", "tio3"]:
        best, all_res = run_all(ds)
        for method, metrics, path in all_res:
            summary.append({"Dataset": ds.upper(), "Method": method, **metrics})

    df_summary = pd.DataFrame(summary)
    df_summary.to_csv(os.path.join(DATA_DIR, "best_augmentation_summary.csv"), index=False)
    print("\n📄 Saved full evaluation summary to best_augmentation_summary.csv")
