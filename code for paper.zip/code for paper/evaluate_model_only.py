import os
import pandas as pd
import numpy as np
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_percentage_error
import subprocess

# === Paths ===
DATA_DIR = "data"

# === Metrics ===
def rmse(y_true, y_pred):
    return np.sqrt(mean_squared_error(y_true, y_pred))

def evaluate(y_true, y_pred):
    results = {}
    if isinstance(y_true, pd.DataFrame):
        columns = y_true.columns
        y_true = y_true.values
        y_pred = y_pred.values
    else:
        columns = [f"Target_{i}" for i in range(y_true.shape[1])]

    for i, name in enumerate(columns):
        results[f"RMSE_{name}"] = rmse(y_true[:, i], y_pred[:, i])
        results[f"R2_{name}"] = r2_score(y_true[:, i], y_pred[:, i])
        results[f"MAPE_{name}"] = mean_absolute_percentage_error(y_true[:, i], y_pred[:, i])
    return results

# === Train & Evaluate ===
def train_and_evaluate(dataset_name, model_version):
    input_file = os.path.join(DATA_DIR, f"sample_{dataset_name}.csv")
    prefix = f"sample_{dataset_name}_{model_version}"
    script = f"train_{dataset_name}_model{'_v2' if model_version == 'v2' else ''}.py"

    print(f"🚀 Running {script} on {input_file}...")

    result = subprocess.run([
        "python", script,
        "--input_file", input_file,
        "--prefix", prefix
    ], capture_output=True, text=True)

    pred_path = os.path.join(DATA_DIR, f"{prefix}_predictions.csv")
    act_path = os.path.join(DATA_DIR, f"{prefix}_actuals.csv")

    if not os.path.exists(pred_path) or not os.path.exists(act_path):
        print(f"[ERROR] Output files not found for {prefix}")
        print(result.stdout)
        print(result.stderr)
        raise FileNotFoundError(f"Missing prediction or actuals for {prefix}")

    preds = pd.read_csv(pred_path)
    actuals = pd.read_csv(act_path)
    return evaluate(actuals, preds)

# === Main Execution ===
if __name__ == "__main__":
    datasets = ["pzt", "tio3"]
    versions = ["v1", "v2"]
    summary = []

    for ds in datasets:
        for version in versions:
            try:
                metrics = train_and_evaluate(ds, version)
                summary.append({
                    "Dataset": ds.upper(),
                    "Model": version,
                    **metrics
                })
            except Exception as e:
                print(f"❌ Failed on {ds.upper()} {version.upper()}: {e}")

    df_summary = pd.DataFrame(summary)
    summary_path = os.path.join(DATA_DIR, "real_data_model_summary.csv")
    df_summary.to_csv(summary_path, index=False)
    print(f"\n✅ Evaluation summary saved to: {summary_path}")
