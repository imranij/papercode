
# Install dependencies
pip install -r requirements.txt

# Start the app
python app.py

