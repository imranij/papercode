from flask import Flask, render_template
from routes.predict import predict_bp
from routes.visualize import visualize_bp
from routes.tables import tables_bp

def create_app():
    app = Flask(__name__, static_folder='static', template_folder='templates')

    # Register route blueprints
    app.register_blueprint(predict_bp, url_prefix='/predict')
    app.register_blueprint(visualize_bp, url_prefix='/visualize')
    app.register_blueprint(tables_bp, url_prefix='/tables')

    @app.route('/')
    def home():
        return render_template('index.html')

    return app

if __name__ == '__main__':
    app = create_app()
    app.run(debug=True)

