# generate_paper_plots.py

import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import mean_squared_error

# Config
INPUT_PATH = "data/last_inputs.csv"
TRUE_PATH = "data/last_actuals.csv"
PRED_PATH = "data/last_predictions.csv"
PLOTS_DIR = "static/plots"

# Load predictions
X = pd.read_csv(INPUT_PATH)
y_pred = pd.read_csv(PRED_PATH)
y_true = pd.read_csv(TRUE_PATH) if os.path.exists(TRUE_PATH) else None

# Get output columns from prediction file
output_cols = y_pred.columns.tolist()
y_pred_vals = y_pred.values
y_true_vals = y_true.values if y_true is not None else None

# Ensure plot directory exists
os.makedirs(PLOTS_DIR, exist_ok=True)

# Plot actual vs predicted
for i, label in enumerate(output_cols):
    plt.figure(figsize=(6, 5))
    if y_true_vals is not None:
        plt.scatter(y_true_vals[:, i], y_pred_vals[:, i], color='blue', edgecolor='k')
        plt.plot([y_true_vals[:, i].min(), y_true_vals[:, i].max()],
                 [y_true_vals[:, i].min(), y_true_vals[:, i].max()],
                 'r--', label='Ideal')
        plt.xlabel("Actual")
    else:
        plt.scatter(np.arange(len(y_pred_vals)), y_pred_vals[:, i], color='blue', edgecolor='k')
        plt.xlabel("Sample Index")

    plt.ylabel("Predicted")
    plt.title(f"PZT: {label} Prediction")
    plt.legend()
    plt.tight_layout()
    filename = f"pzt_{label.lower().replace(' ', '_')}.png"
    plt.savefig(os.path.join(PLOTS_DIR, filename))
    plt.close()

# RMSE plot (only if ground truth is available)
if y_true_vals is not None:
    rmse_scores = [mean_squared_error(y_true_vals[:, i], y_pred_vals[:, i]) ** 0.5 for i in range(len(output_cols))]
    plt.figure(figsize=(6, 5))
    plt.bar(output_cols, rmse_scores, color='skyblue', edgecolor='black')
    plt.title("PZT RMSE by Output Variable")
    plt.ylabel("RMSE")
    plt.tight_layout()
    plt.savefig(os.path.join(PLOTS_DIR, "pzt_rmse_summary.png"))
    plt.close()

print("✅ Paper plots generated using real predictions.")
