# -*- coding: utf-8 -*-
"""
Created on Mon Jul 28 13:41:53 2025

@author: imran.imran
"""

# -*- coding: utf-8 -*-
"""
Created on Mon Jul 28 12:45:00 2025
Description: Generate top-k recommended samples based on distance from normalized prediction centroid
"""

import os
import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler

# --- Setup ---
DATA_DIR = "predictions"
OUTPUT_DIR = os.path.join(DATA_DIR, "predictiveanalysis")
TOP_K = 10
os.makedirs(OUTPUT_DIR, exist_ok=True)

# --- Load Inputs and Predictions for PZT ---
pzt_inputs = pd.read_csv(os.path.join(DATA_DIR, "sample_pzt.csv"))
pzt_preds = pd.read_csv(os.path.join(DATA_DIR, "stacked_v123_pzt_predictions_v2.csv"))

# --- Load Inputs and Predictions for TIO3 ---
tio3_inputs = pd.read_csv(os.path.join(DATA_DIR, "sample_tio3.csv"))
tio3_preds = pd.read_csv(os.path.join(DATA_DIR, "stacked_v123_tio3_predictions_v2.csv"))

# --- Recommendation Function ---
def recommend_top_k(input_df, pred_df, k=10):
    # Step 1: Normalize predictions
    scaler = MinMaxScaler()
    norm_pred = scaler.fit_transform(pred_df)

    # Step 2: Compute centroid
    centroid = np.mean(norm_pred, axis=0)

    # Step 3: Compute Euclidean distances
    distances = np.linalg.norm(norm_pred - centroid, axis=1)

    # Step 4: Get top-k farthest from centroid (assumed optimal)
    top_k_idx = np.argsort(distances)[-k:]
    top_k_df = input_df.iloc[top_k_idx].copy()
    top_k_df["Score"] = distances[top_k_idx]

    # Step 5: Sort by descending score
    return top_k_df.sort_values("Score", ascending=False)

# --- Apply to both datasets ---
pzt_top10 = recommend_top_k(pzt_inputs, pzt_preds, TOP_K)
tio3_top10 = recommend_top_k(tio3_inputs, tio3_preds, TOP_K)

# --- Save outputs ---
pzt_output_path = os.path.join(OUTPUT_DIR, "PZT_Top10_Recommendations.csv")
tio3_output_path = os.path.join(OUTPUT_DIR, "TIO3_Top10_Recommendations.csv")

pzt_top10.to_csv(pzt_output_path, index=False)
tio3_top10.to_csv(tio3_output_path, index=False)

print("✅ Top-10 recommendations saved:")
print(f"📄 {pzt_output_path}")
print(f"📄 {tio3_output_path}")
