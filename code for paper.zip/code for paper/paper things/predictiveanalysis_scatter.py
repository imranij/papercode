
# -*- coding: utf-8 -*-
"""
Revised plotting script
- Replaces line charts with Sample-ID scatter plots (markers only, light jitter; no lines)
- Adds Parity plots (Actual vs Predicted) with RMSE / R² / MAPE annotated per model
- Adds Residuals vs Predicted plots (to check bias/heteroscedasticity/outliers)
"""
import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_percentage_error

# -----------------------
# Config
# -----------------------
DATA_DIR = "predictions"
OUTPUT_SUBDIR = "predictiveanalysis_scatter"
SAMPLE_SLICE = slice(0, 150)  # for Sample-ID scatter plots only
JITTER_WIDTH = 0.15           # "light jitter" in x for Sample-ID scatter
MARKER_SIZE = 28
ALPHA = 0.85

# Target abbreviation mapping
target_abbr = {
    "SinteredDensity": "Sintered Density",
    "DielectricConstant": "Dielectric Constant",
    "QualityFactor": "Quality Factor",
    "ElectricalResistivity": "Electrical Resistivity",
    "TemperatureCoefficientOfResistivity": "Temperature Coefficient of Resistivity",
    "CurieTemperature": "Curie Temperature"
}

# -----------
# target_abbr = {
    # "SinteredDensity": "SD",
    # "DielectricConstant": "DC",
    # "QualityFactor": "QF",
    # "ElectricalResistivity": "ER",
    # "TemperatureCoefficientOfResistivity": "TCR",
    # "CurieTemperature": "CT"
# }

# --

# -----------------------
# Helpers
# -----------------------
def ensure_dir(path):
    os.makedirs(path, exist_ok=True)

def metrics(y_true, y_pred):
    rmse = np.sqrt(mean_squared_error(y_true, y_pred))
    r2 = r2_score(y_true, y_pred)
    mape = mean_absolute_percentage_error(y_true, y_pred)
    return rmse, r2, mape

def parity_plot(ax, y_true, y_pred, model_name, title_suffix=""):
    # Scatter: Actual vs Predicted
    ax.scatter(y_true, y_pred, s=MARKER_SIZE, alpha=ALPHA, edgecolor='none')
    # Identity line
    vmin = np.nanmin(np.concatenate([y_true, y_pred]))
    vmax = np.nanmax(np.concatenate([y_true, y_pred]))
    pad = 0.05 * (vmax - vmin if vmax > vmin else 1.0)
    ax.plot([vmin - pad, vmax + pad], [vmin - pad, vmax + pad], linestyle='--', linewidth=1, color='black')
    ax.set_xlabel("Actual")
    ax.set_ylabel("Predicted")
    ax.set_aspect('equal', adjustable='box')
    ax.grid(True, linestyle='--', alpha=0.4)
    rmse, r2, mape = metrics(y_true, y_pred)
    ax.set_title(f"{model_name}{title_suffix}")
    # On-figure metrics annotation
    ax.text(0.02, 0.98, f"RMSE: {rmse:.3g}\nR²: {r2:.3f}\nMAPE: {mape:.2%}",
            transform=ax.transAxes, ha='left', va='top',
            bbox=dict(boxstyle='round,pad=0.3', facecolor='white', alpha=0.8, linewidth=0.5))

def residuals_vs_predicted_plot(ax, y_true, y_pred, model_name, title_suffix=""):
    resid = y_true - y_pred
    ax.scatter(y_pred, resid, s=MARKER_SIZE, alpha=ALPHA, edgecolor='none')
    ax.axhline(0.0, color='black', linestyle='--', linewidth=1)
    ax.set_xlabel("Predicted")
    ax.set_ylabel("Residual (Actual - Predicted)")
    ax.grid(True, linestyle='--', alpha=0.4)
    ax.set_title(f"{model_name}{title_suffix}")

def sample_id_scatter(ax, series, label, x_slice=SAMPLE_SLICE, jitter_width=JITTER_WIDTH):
    # x positions with light jitter; markers only (no lines)
    x = np.arange(len(series))[x_slice]
    y = np.asarray(series)[x_slice]
    # jitter
    jitter = np.random.uniform(-jitter_width, jitter_width, size=x.shape)
    ax.scatter(x + jitter, y, s=MARKER_SIZE, alpha=ALPHA, label=label, edgecolor='none')

def plot_sample_id_scatter_per_target(dataset_name, model_dfs, actuals_df, targets, out_dir):
    # One figure per target, scatter per model vs Sample ID (with light jitter); no lines
    for target in targets:
        short = target_abbr.get(target, target)
        fig, ax = plt.subplots(figsize=(12, 5))
        for model_name, df in model_dfs.items():
            sample_id_scatter(ax, df[target].values, label=model_name)
        ax.set_title(f"{dataset_name} - {short}: Sample-ID")
        ax.set_xlabel("Sample ID")
        ax.set_ylabel(short)
        ax.grid(True, linestyle='--', alpha=0.4)
        ax.legend()
        fig.tight_layout()
        fig.savefig(os.path.join(out_dir, f"{dataset_name}_{target}_SampleID_Scatter.pdf"))
        plt.close(fig)

def plot_parity_and_residuals_per_model(dataset_name, model_dfs, actuals_df, targets, out_dir):
    # For each target, create two multi-page style outputs:
    # (a) Parity plots: one panel per model (excluding "Actual")
    # (b) Residuals vs Predicted: one panel per model (excluding "Actual")
    models_to_plot = {k: v for k, v in model_dfs.items() if k != "Actual"}

    for target in targets:
        short = target_abbr.get(target, target)
        y_true = actuals_df[target].values

        # ----- Parity plots (Actual vs Predicted) -----
        n_models = len(models_to_plot)
        ncols = 3
        nrows = int(np.ceil(n_models / ncols))
        fig, axes = plt.subplots(nrows=nrows, ncols=ncols, figsize=(6*ncols, 4.8*nrows))
        axes = np.atleast_2d(axes)
        axes_flat = axes.flatten()

        for ax in axes_flat[n_models:]:
            ax.axis('off')

        for ax, (model_name, df) in zip(axes_flat, models_to_plot.items()):
            y_pred = df[target].values
            parity_plot(ax, y_true, y_pred, model_name, title_suffix=f" • {short}")

        fig.suptitle(f"{dataset_name} • {short} • Parity (Actual vs Predicted)", fontsize=14)
        fig.tight_layout(rect=[0, 0, 1, 0.97])
        fig.savefig(os.path.join(out_dir, f"{dataset_name}_{target}_ParityPlots.pdf"))
        plt.close(fig)

        # ----- Residuals vs Predicted -----
        fig, axes = plt.subplots(nrows=nrows, ncols=ncols, figsize=(6*ncols, 4.8*nrows))
        axes = np.atleast_2d(axes)
        axes_flat = axes.flatten()

        for ax in axes_flat[n_models:]:
            ax.axis('off')

        for ax, (model_name, df) in zip(axes_flat, models_to_plot.items()):
            y_pred = df[target].values
            residuals_vs_predicted_plot(ax, y_true, y_pred, model_name, title_suffix=f" • {short}")

        fig.suptitle(f"{dataset_name} • {short} • Residuals vs Predicted", fontsize=14)
        fig.tight_layout(rect=[0, 0, 1, 0.97])
        fig.savefig(os.path.join(out_dir, f"{dataset_name}_{target}_ResidualsVsPredicted.pdf"))
        plt.close(fig)

def plot_metric_barcharts(dataset_name, model_dfs, actuals_df, targets, out_dir):
    # Optional: keep combined metrics bar charts across targets (RMSE/R2/MAPE) for quick comparison
    rows = []
    for model_name, df in model_dfs.items():
        if model_name == "Actual":
            continue
        for target in targets:
            y_true = actuals_df[target].values
            y_pred = df[target].values
            rmse, r2, mape = metrics(y_true, y_pred)
            rows.append({
                "Model": model_name,
                "Target": target_abbr.get(target, target),
                "RMSE": rmse,
                "R2": r2,
                "MAPE": mape
            })
    metric_df = pd.DataFrame(rows)

    # Use matplotlib (no seaborn dependency required)
    fig, axes = plt.subplots(3, 1, figsize=(14, 12))
    # RMSE
    ax = axes[0]
    for model in metric_df["Model"].unique():
        sub = metric_df[metric_df["Model"] == model]
        ax.plot(sub["Target"], sub["RMSE"], marker='o', label=model)  # small line to connect categories
    ax.set_title("RMSE per Target")
    ax.set_ylabel("RMSE")
    ax.grid(True, linestyle='--', alpha=0.4)
    ax.legend()
    # MAPE
    ax = axes[1]
    for model in metric_df["Model"].unique():
        sub = metric_df[metric_df["Model"] == model]
        ax.plot(sub["Target"], sub["MAPE"], marker='o', label=model)
    ax.set_title("MAPE per Target")
    ax.set_ylabel("MAPE")
    ax.grid(True, linestyle='--', alpha=0.4)
    # R2
    ax = axes[2]
    for model in metric_df["Model"].unique():
        sub = metric_df[metric_df["Model"] == model]
        ax.plot(sub["Target"], sub["R2"], marker='o', label=model)
    ax.set_title("R² per Target")
    ax.set_ylabel("R²")
    ax.set_xlabel("Target Property")
    ax.grid(True, linestyle='--', alpha=0.4)

    fig.tight_layout()
    fig.savefig(os.path.join(out_dir, f"{dataset_name}_Model_Metrics_Chart.pdf"))
    plt.close(fig)

def load_dataset(kind):
    """kind: 'PZT' or 'TIO3'"""
    if kind == 'PZT':
        actuals = pd.read_csv(os.path.join(DATA_DIR, "sample_pzt_actuals.csv"))
        v1_preds = pd.read_csv(os.path.join(DATA_DIR, "sample_pzt_predictions.csv"))
        v2_preds = pd.read_csv(os.path.join(DATA_DIR, "sample_pzt_v2_predictions.csv"))
        v3_preds = pd.read_csv(os.path.join(DATA_DIR, "sample_pzt_v3_predictions.csv"))
        stacked_v1v2 = pd.read_csv(os.path.join(DATA_DIR, "stacked_v12_pzt_predictions_v1v2.csv"))
        stacked_v123 = pd.read_csv(os.path.join(DATA_DIR, "stacked_v123_pzt_predictions_v2.csv"))
    elif kind == 'TIO3':
        actuals = pd.read_csv(os.path.join(DATA_DIR, "sample_tio3_actuals.csv"))
        v1_preds = pd.read_csv(os.path.join(DATA_DIR, "sample_tio3_predictions.csv"))
        v2_preds = pd.read_csv(os.path.join(DATA_DIR, "sample_tio3_v2_predictions.csv"))
        v3_preds = pd.read_csv(os.path.join(DATA_DIR, "sample_tio3_v3_predictions.csv"))
        stacked_v1v2 = pd.read_csv(os.path.join(DATA_DIR, "stacked_v12_tio3_predictions_v1v2.csv"))
        stacked_v123 = pd.read_csv(os.path.join(DATA_DIR, "stacked_v123_tio3_predictions_v2.csv"))
    else:
        raise ValueError("Unknown dataset kind")

    model_dfs = {
        "Actual": actuals,
        "BaselineNet": v1_preds,
        "DeepNormNet": v2_preds,
        "MultiHeadNet": v3_preds,
        "LightEnsemble": stacked_v1v2,
        "FullEnsemble": stacked_v123
    }
    targets = actuals.columns.tolist()
    return model_dfs, actuals, targets

def process_dataset(kind):
    dataset_name = "PZT" if kind == "PZT" else "TiO₃"
    out_dir = os.path.join(DATA_DIR, OUTPUT_SUBDIR, kind.lower())
    ensure_dir(out_dir)

    model_dfs, actuals_df, targets = load_dataset(kind)

    # 1) Sample-ID scatter plots (markers only, light jitter; no lines)
    plot_sample_id_scatter_per_target(dataset_name, model_dfs, actuals_df, targets, out_dir)

    # 2) Parity plots with on-figure RMSE/R²/MAPE
    # 3) Residuals vs Predicted plots
    plot_parity_and_residuals_per_model(dataset_name, model_dfs, actuals_df, targets, out_dir)

    # (Optional) 4) Overall metrics chart
    plot_metric_barcharts(dataset_name, model_dfs, actuals_df, targets, out_dir)

def main():
    # Reproducible jitter (optional)
    np.random.seed(42)

    # Output root
    root_out = os.path.join(DATA_DIR, OUTPUT_SUBDIR)
    ensure_dir(root_out)

    # Run both datasets, matching your original script
    for kind in ("PZT", "TIO3"):
        process_dataset(kind)

    print(f"✅ Scatter-based visual outputs saved under: {os.path.join(DATA_DIR, OUTPUT_SUBDIR)}")

if __name__ == "__main__":
    main()
