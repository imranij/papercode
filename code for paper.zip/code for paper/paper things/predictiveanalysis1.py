# -*- coding: utf-8 -*-
"""
Created on Mon Jul 28 10:10:29 2025
@author: imran.imran
"""

import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_percentage_error
import seaborn as sns
# ---------- Scatter/metrics utilities ----------
from math import sqrt
import matplotlib as mpl

def compute_metrics(y_true, y_pred):
    mse = mean_squared_error(y_true, y_pred)
    rmse = sqrt(mse)
    r2 = r2_score(y_true, y_pred)
    try:
        mape = mean_absolute_percentage_error(y_true, y_pred)
    except Exception:
        # safeguard for old sklearn
        y_true_np = np.asarray(y_true, float)
        y_pred_np = np.asarray(y_pred, float)
        mape = np.mean(np.abs((y_true_np - y_pred_np) / np.clip(np.abs(y_true_np), 1e-8, None)))
    return rmse, r2, mape

def parity_ax(ax, y_true, y_pred, label, color=None, s=24, alpha=0.55):
    # scatter
    ax.scatter(y_true, y_pred, s=s, alpha=alpha, label=label, color=color, edgecolor="none")
    # 1:1 line
    mins = np.nanmin([y_true.min(), y_pred.min()])
    maxs = np.nanmax([y_true.max(), y_pred.max()])
    pad = 0.02 * (maxs - mins if maxs > mins else 1.0)
    lo, hi = mins - pad, maxs + pad
    ax.plot([lo, hi], [lo, hi], ls="--", lw=1.2, color="black", alpha=0.7)
    ax.set_xlim(lo, hi); ax.set_ylim(lo, hi)

def annotate_metrics(ax, y_true, y_pred, xy=(0.02, 0.98)):
    rmse, r2, mape = compute_metrics(y_true, y_pred)
    ax.text(xy[0], xy[1],
            f"RMSE={rmse:.3g}\nR²={r2:.3f}\nMAPE={mape:.2%}",
            transform=ax.transAxes, va="top", ha="left",
            bbox=dict(boxstyle="round,pad=0.3", facecolor="white", alpha=0.7))

def residual_scatter_ax(ax, y_true, y_pred, label, color=None, s=22, alpha=0.6):
    res = y_true - y_pred
    ax.scatter(y_pred, res, s=s, alpha=alpha, label=label, color=color, edgecolor="none")
    ax.axhline(0, color="black", lw=1.0, ls="--", alpha=0.7)

# consistent color cycle across plots
PALETTE = mpl.cm.get_cmap("tab10")

# --- Target abbreviation mapping ---
target_abbr = {
    "SinteredDensity": "SD",
    "DielectricConstant": "DC",
    "QualityFactor": "QF",
    "ElectricalResistivity": "ER",
    "TemperatureCoefficientOfResistivity": "TCR",
    "CurieTemperature": "CT"
}

# --- Setup Paths ---
DATA_DIR = "predictions"
output_dir = os.path.join(DATA_DIR, "predictiveanalysis")
os.makedirs(output_dir, exist_ok=True)

# --- Load PZT ---
actuals = pd.read_csv(os.path.join(DATA_DIR, "sample_pzt_actuals.csv"))
v1_preds = pd.read_csv(os.path.join(DATA_DIR, "sample_pzt_predictions.csv"))
v2_preds = pd.read_csv(os.path.join(DATA_DIR, "sample_pzt_v2_predictions.csv"))
v3_preds = pd.read_csv(os.path.join(DATA_DIR, "sample_pzt_v3_predictions.csv"))
stacked_v1v2 = pd.read_csv(os.path.join(DATA_DIR, "stacked_v12_pzt_predictions_v1v2.csv"))
stacked_v123 = pd.read_csv(os.path.join(DATA_DIR, "stacked_v123_pzt_predictions_v2.csv"))

model_dfs = {
    "Actual": actuals,
    "BaselineNet": v1_preds,
    "DeepNormNet": v2_preds,
    "MultiHeadNet": v3_preds,
    "LightEnsemble": stacked_v1v2,
    "FullEnsemble": stacked_v123
}

line_styles = ["solid", "dashed", "dotted", "dashdot", (0, (3, 1, 1, 1)), (0, (5, 2))]
line_widths = [2.5, 2, 2, 2, 2, 2]
sample_slice = slice(0, 150)
targets = actuals.columns.tolist()

# === 1. Line Charts ===
for target in targets:
    short = target_abbr.get(target, target)
    fig, ax = plt.subplots(figsize=(12, 5))
    for i, (model_name, df) in enumerate(model_dfs.items()):
        ax.plot(df[target].values[sample_slice], label=model_name,
                linestyle=line_styles[i % len(line_styles)],
                linewidth=line_widths[i % len(line_widths)])
    ax.set_title(f"PZT - Prediction Comparison for {short}", fontsize=14)
    ax.set_xlabel("Sample ID")
    ax.set_ylabel(short)
    ax.legend()
    ax.grid(True, linestyle='--', alpha=0.5)
    fig.tight_layout()
    fig.savefig(os.path.join(output_dir, f"PZT_Prediction_LineChart_{target}.pdf"))
    plt.close(fig)

# === 2. Residual Plots ===
models_to_plot = {k: v for k, v in model_dfs.items() if k != "Actual"}
for target in targets:
    short = target_abbr.get(target, target)
    fig, ax = plt.subplots(figsize=(12, 5))
    y_true = actuals[target].values
    for i, (model_name, df) in enumerate(models_to_plot.items()):
        y_pred = df[target].values
        residuals = y_true - y_pred
        ax.plot(residuals[sample_slice], label=model_name,
                linestyle=line_styles[i % len(line_styles)],
                linewidth=line_widths[i % len(line_widths)])
    ax.set_title(f"PZT - Residual Plot for {short} (Actual - Predicted)", fontsize=14)
    ax.set_xlabel("Sample ID")
    ax.set_ylabel("Residual")
    ax.axhline(0, color='black', linestyle='--', linewidth=1)
    ax.legend()
    ax.grid(True, linestyle='--', alpha=0.5)
    fig.tight_layout()
    fig.savefig(os.path.join(output_dir, f"PZT_Residual_{target}.pdf"))
    plt.close(fig)

# === 3. Combined Bar Chart ===
metrics = {"Model": [], "Target": [], "RMSE": [], "R2": [], "MAPE": []}
for model_name, df in model_dfs.items():
    if model_name == "Actual":
        continue
    for target in targets:
        y_true = actuals[target].values
        y_pred = df[target].values
        short = target_abbr.get(target, target)
        metrics["Model"].append(model_name)
        metrics["Target"].append(short)
        metrics["RMSE"].append(np.sqrt(mean_squared_error(y_true, y_pred)))
        metrics["R2"].append(r2_score(y_true, y_pred))
        metrics["MAPE"].append(mean_absolute_percentage_error(y_true, y_pred))

metric_df = pd.DataFrame(metrics)

fig, axes = plt.subplots(2, 2, figsize=(16, 10), gridspec_kw={'height_ratios': [1, 1.2]})
sns.set(style="whitegrid")

sns.barplot(data=metric_df, x="Target", y="RMSE", hue="Model", ax=axes[0, 0])
axes[0, 0].set_title("RMSE per Target")
axes[0, 0].set_ylabel("RMSE")
axes[0, 0].set_xlabel("")

sns.barplot(data=metric_df, x="Target", y="MAPE", hue="Model", ax=axes[0, 1])
axes[0, 1].set_title("MAPE per Target")
axes[0, 1].set_ylabel("MAPE")
axes[0, 1].set_xlabel("")

ax_r2 = fig.add_subplot(2, 1, 2)
sns.barplot(data=metric_df, x="Target", y="R2", hue="Model", ax=ax_r2)
ax_r2.set_title("R² per Target")
ax_r2.set_ylabel("R² Score")
ax_r2.set_xlabel("Target Property")

fig.tight_layout()
fig.savefig(os.path.join(output_dir, "PZT_Model_Metrics_BarCharts.pdf"))
plt.close(fig)

print(f"✅ All abbreviated visual outputs saved to: {output_dir}")

# ---------- PZT: Scatter-based diagnostics ----------
pzt_models_to_plot = {k: v for k, v in model_dfs.items() if k != "Actual"}
pzt_targets = actuals.columns.tolist()

# (A) Parity plots (per target => multi-page PDF)
with PdfPages(os.path.join(output_dir, "PZT_Parity_Plots.pdf")) as pdf:
    for target in pzt_targets:
        y_true = actuals[target].values
        fig, ax = plt.subplots(figsize=(6.5, 6.2))
        for i, (name, df) in enumerate(pzt_models_to_plot.items()):
            y_pred = df[target].values
            parity_ax(ax, y_true, y_pred, label=name, color=PALETTE(i))
        ax.set_title(f"PZT — Parity Plot: {target_abbr.get(target, target)}")
        ax.set_xlabel("Actual")
        ax.set_ylabel("Predicted")
        ax.legend(frameon=True)
        fig.tight_layout(); pdf.savefig(fig); plt.close(fig)

# (B) Residuals vs Predicted (per target => multi-page PDF)
with PdfPages(os.path.join(output_dir, "PZT_Residuals_vs_Predicted.pdf")) as pdf:
    for target in pzt_targets:
        y_true = actuals[target].values
        fig, ax = plt.subplots(figsize=(6.8, 5.2))
        for i, (name, df) in enumerate(pzt_models_to_plot.items()):
            y_pred = df[target].values
            residual_scatter_ax(ax, y_true, y_pred, label=name, color=PALETTE(i))
        ax.set_title(f"PZT — Residuals vs Predicted: {target_abbr.get(target, target)}")
        ax.set_xlabel("Predicted")
        ax.set_ylabel("Residual (Actual − Pred)")
        ax.legend(frameon=True)
        fig.tight_layout(); pdf.savefig(fig); plt.close(fig)

# (C) Sample-ID scatter (markers only; no lines; light jitter)
with PdfPages(os.path.join(output_dir, "PZT_SampleID_Scatter.pdf")) as pdf:
    n = len(actuals)
    x = np.arange(n)
    jitter = 0.08 * (np.random.rand(n) - 0.5)  # subtle jitter to reduce overlap

    for target in pzt_targets:
        fig, ax = plt.subplots(figsize=(12, 4.8))
        # actuals
        ax.scatter(x, actuals[target].values, s=26, label="Actual",
                   color="black", alpha=0.8, marker="o", edgecolor="none")
        # predictions per model
        for i, (name, df) in enumerate(pzt_models_to_plot.items()):
            ax.scatter(x + jitter, df[target].values, s=22,
                       label=name, color=PALETTE(i), alpha=0.55, edgecolor="none")
        ax.set_title(f"PZT — Sample-ID Scatter: {target_abbr.get(target, target)}")
        ax.set_xlabel("Sample ID"); ax.set_ylabel(target_abbr.get(target, target))
        ax.grid(True, ls="--", alpha=0.4)
        ax.legend(ncol=3, fontsize=9)
        fig.tight_layout(); pdf.savefig(fig); plt.close(fig)


# -*- coding: utf-8 -*-
"""
Created on Mon Jul 28 10:10:29 2025
@author: imran.imran
"""
import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_percentage_error
import seaborn as sns

# --- Abbreviation mapping ---
target_abbr = {
    "SinteredDensity": "SD",
    "DielectricConstant": "DC",
    "QualityFactor": "QF",
    "ElectricalResistivity": "ER",
    "TemperatureCoefficientOfResistivity": "TCR",
    "CurieTemperature": "CT"
}

# --- Setup Paths ---
DATA_DIR = "predictions"
output_dir = os.path.join(DATA_DIR, "predictiveanalysis")
os.makedirs(output_dir, exist_ok=True)

# --- Load All Model Predictions and Actuals for TiO3 ---
actuals = pd.read_csv(os.path.join(DATA_DIR, "sample_tio3_actuals.csv"))
v1_preds = pd.read_csv(os.path.join(DATA_DIR, "sample_tio3_predictions.csv"))
v2_preds = pd.read_csv(os.path.join(DATA_DIR, "sample_tio3_v2_predictions.csv"))
v3_preds = pd.read_csv(os.path.join(DATA_DIR, "sample_tio3_v3_predictions.csv"))
stacked_v1v2 = pd.read_csv(os.path.join(DATA_DIR, "stacked_v12_tio3_predictions_v1v2.csv"))
stacked_v123 = pd.read_csv(os.path.join(DATA_DIR, "stacked_v123_tio3_predictions_v2.csv"))

# --- Assign model names and dataframes ---
model_dfs = {
    "Actual": actuals,
    "BaselineNet": v1_preds,
    "DeepNormNet": v2_preds,
    "MultiHeadNet": v3_preds,
    "LightEnsemble": stacked_v1v2,
    "FullEnsemble": stacked_v123
}

# --- Plot Settings ---
line_styles = ["solid", "dashed", "dotted", "dashdot", (0, (3, 1, 1, 1)), (0, (5, 2))]
line_widths = [2.5, 2, 2, 2, 2, 2]
sample_slice = slice(0, 150)
targets = actuals.columns.tolist()

# === 1. Line Charts ===
for target in targets:
    short = target_abbr.get(target, target)
    fig, ax = plt.subplots(figsize=(12, 5))
    for i, (model_name, df) in enumerate(model_dfs.items()):
        ax.plot(df[target].values[sample_slice], label=model_name,
                linestyle=line_styles[i % len(line_styles)],
                linewidth=line_widths[i % len(line_widths)])
    ax.set_title(f"TiO₃ - Prediction Comparison for {short}", fontsize=14)
    ax.set_xlabel("Sample ID")
    ax.set_ylabel(short)
    ax.legend()
    ax.grid(True, linestyle='--', alpha=0.5)
    fig.tight_layout()
    fig.savefig(os.path.join(output_dir, f"TIO3_Prediction_LineChart_{target}.pdf"))
    plt.close(fig)

# === 2. Residual Plots ===
models_to_plot = {k: v for k, v in model_dfs.items() if k != "Actual"}
for target in targets:
    short = target_abbr.get(target, target)
    fig, ax = plt.subplots(figsize=(12, 5))
    y_true = actuals[target].values
    for i, (model_name, df) in enumerate(models_to_plot.items()):
        y_pred = df[target].values
        residuals = y_true - y_pred
        ax.plot(residuals[sample_slice], label=model_name,
                linestyle=line_styles[i % len(line_styles)],
                linewidth=line_widths[i % len(line_widths)])
    ax.set_title(f"TiO₃ - Residual Plot for {short} (Actual - Predicted)", fontsize=14)
    ax.set_xlabel("Sample ID")
    ax.set_ylabel("Residual")
    ax.axhline(0, color='black', linestyle='--', linewidth=1)
    ax.legend()
    ax.grid(True, linestyle='--', alpha=0.5)
    fig.tight_layout()
    fig.savefig(os.path.join(output_dir, f"TIO3_Residual_{target}.pdf"))
    plt.close(fig)

# === 3. Combined Bar Chart ===
metrics = {"Model": [], "Target": [], "RMSE": [], "R2": [], "MAPE": []}
for model_name, df in model_dfs.items():
    if model_name == "Actual":
        continue
    for target in targets:
        y_true = actuals[target].values
        y_pred = df[target].values
        short = target_abbr.get(target, target)
        metrics["Model"].append(model_name)
        metrics["Target"].append(short)
        metrics["RMSE"].append(np.sqrt(mean_squared_error(y_true, y_pred)))
        metrics["R2"].append(r2_score(y_true, y_pred))
        metrics["MAPE"].append(mean_absolute_percentage_error(y_true, y_pred))

metric_df = pd.DataFrame(metrics)

# Plot into a single combined figure
fig, axes = plt.subplots(2, 2, figsize=(16, 10), gridspec_kw={'height_ratios': [1, 1.2]})
sns.set(style="whitegrid")

sns.barplot(data=metric_df, x="Target", y="RMSE", hue="Model", ax=axes[0, 0])
axes[0, 0].set_title("RMSE per Target")
axes[0, 0].set_ylabel("RMSE")
axes[0, 0].set_xlabel("")

sns.barplot(data=metric_df, x="Target", y="MAPE", hue="Model", ax=axes[0, 1])
axes[0, 1].set_title("MAPE per Target")
axes[0, 1].set_ylabel("MAPE")
axes[0, 1].set_xlabel("")

ax_r2 = fig.add_subplot(2, 1, 2)
sns.barplot(data=metric_df, x="Target", y="R2", hue="Model", ax=ax_r2)
ax_r2.set_title("R² per Target")
ax_r2.set_ylabel("R² Score")
ax_r2.set_xlabel("Target Property")

fig.tight_layout()
fig.savefig(os.path.join(output_dir, "TIO3_Model_Metrics_BarCharts.pdf"))
plt.close(fig)

print(f"✅ All TiO₃ visual outputs saved with abbreviated target names in: {output_dir}")


# ---------- TiO3: Scatter-based diagnostics ----------
tio3_models_to_plot = {k: v for k, v in model_dfs.items() if k != "Actual"}
tio3_targets = actuals.columns.tolist()

# (A) Parity plots
with PdfPages(os.path.join(output_dir, "TIO3_Parity_Plots.pdf")) as pdf:
    for target in tio3_targets:
        y_true = actuals[target].values
        fig, ax = plt.subplots(figsize=(6.5, 6.2))
        for i, (name, df) in enumerate(tio3_models_to_plot.items()):
            y_pred = df[target].values
            parity_ax(ax, y_true, y_pred, label=name, color=PALETTE(i))
        ax.set_title(f"TiO\u2083 — Parity Plot: {target_abbr.get(target, target)}")
        ax.set_xlabel("Actual"); ax.set_ylabel("Predicted")
        ax.legend(frameon=True)
        fig.tight_layout(); pdf.savefig(fig); plt.close(fig)

# (B) Residuals vs Predicted
with PdfPages(os.path.join(output_dir, "TIO3_Residuals_vs_Predicted.pdf")) as pdf:
    for target in tio3_targets:
        y_true = actuals[target].values
        fig, ax = plt.subplots(figsize=(6.8, 5.2))
        for i, (name, df) in enumerate(tio3_models_to_plot.items()):
            y_pred = df[target].values
            residual_scatter_ax(ax, y_true, y_pred, label=name, color=PALETTE(i))
        ax.set_title(f"TiO\u2083 — Residuals vs Predicted: {target_abbr.get(target, target)}")
        ax.set_xlabel("Predicted"); ax.set_ylabel("Residual (Actual − Pred)")
        ax.legend(frameon=True)
        fig.tight_layout(); pdf.savefig(fig); plt.close(fig)

# (C) Sample-ID scatter (markers; no lines; jitter)
with PdfPages(os.path.join(output_dir, "TIO3_SampleID_Scatter.pdf")) as pdf:
    n = len(actuals)
    x = np.arange(n)
    jitter = 0.08 * (np.random.rand(n) - 0.5)

    for target in tio3_targets:
        fig, ax = plt.subplots(figsize=(12, 4.8))
        ax.scatter(x, actuals[target].values, s=26, label="Actual",
                   color="black", alpha=0.8, marker="o", edgecolor="none")
        for i, (name, df) in enumerate(tio3_models_to_plot.items()):
            ax.scatter(x + jitter, df[target].values, s=22,
                       label=name, color=PALETTE(i), alpha=0.55, edgecolor="none")
        ax.set_title(f"TiO\u2083 — Sample-ID Scatter: {target_abbr.get(target, target)}")
        ax.set_xlabel("Sample ID"); ax.set_ylabel(target_abbr.get(target, target))
        ax.grid(True, ls="--", alpha=0.4)
        ax.legend(ncol=3, fontsize=9)
        fig.tight_layout(); pdf.savefig(fig); plt.close(fig)

