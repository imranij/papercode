import os
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# ----------------- CONFIG -----------------
sns.set(style="whitegrid")
DATA_DIR = "."  # folder containing CSVs
OUTPUT_DIR = os.path.join(DATA_DIR, "descriptive")
os.makedirs(OUTPUT_DIR, exist_ok=True)

# Load datasets
pzt_df = pd.read_csv(os.path.join(DATA_DIR, "sample_pzt.csv"))
tio3_df = pd.read_csv(os.path.join(DATA_DIR, "sample_tio3.csv"))

# Function to generate summary table and distribution grid
def create_combined_summary_and_distributions(df, name):
    # -------- Summary Statistics --------
    desc = df.describe().T
    desc["missing"] = df.isnull().sum()
    desc["zero_count"] = (df == 0).sum()

    fig_summary, ax = plt.subplots(figsize=(12, len(desc) * 0.4))
    ax.axis('off')
    table = ax.table(cellText=desc.round(3).values,
                     colLabels=desc.columns,
                     rowLabels=desc.index,
                     loc='center')
    table.auto_set_font_size(False)
    table.set_fontsize(8)
    table.scale(1.2, 1.2)
    plt.title(f"{name} - Summary Statistics", fontsize=14)
    summary_path = os.path.join(OUTPUT_DIR, f"{name}_01_summary_stats.pdf")
    fig_summary.savefig(summary_path, bbox_inches='tight')
    plt.close(fig_summary)

    # -------- Combined Distributions --------
    num_cols = len(df.columns)
    cols = 3
    rows = (num_cols + cols - 1) // cols
    fig_dist, axes = plt.subplots(rows, cols, figsize=(cols * 5, rows * 4))
    axes = axes.flatten()

    for i, col in enumerate(df.columns):
        sns.histplot(df[col], kde=True, bins=30, ax=axes[i], color="steelblue")
        axes[i].set_title(f"Distribution of {col}")
        axes[i].set_xlabel(col)

    for j in range(i + 1, len(axes)):
        fig_dist.delaxes(axes[j])

    fig_dist.tight_layout()
    dist_path = os.path.join(OUTPUT_DIR, f"{name}_02_distribution_combined.pdf")
    fig_dist.savefig(dist_path, bbox_inches='tight')
    plt.close(fig_dist)

# Run for both datasets
create_combined_summary_and_distributions(pzt_df, "PZT")
create_combined_summary_and_distributions(tio3_df, "TiO3")

print(f"✅ Figures saved in: {OUTPUT_DIR}")
