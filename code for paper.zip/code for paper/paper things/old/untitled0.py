# -*- coding: utf-8 -*-
"""
Created on Sun Jul 27 15:13:02 2025

@author: imran.imran
"""

import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.backends.backend_pdf
import seaborn as sns

# OriginPro-like palette
origin_palette = ["#1f497d", "#c0504d", "#9bbb59", "#8064a2", "#4bacc6", "#f79646"]
sns.set(style="whitegrid")

import pandas as pd

# Define PZT dataset performance
pzt_data = {
    "Model": ["BaselineNet", "DeepNormNet", "MultiHeadNet", "LightEnsemble", "FullEnsemble"],
    "RMSE_SD": [0.227, 0.256, 0.032, 0.228, 0.172],
    "R2_SD": [0.756, 0.691, 0.995, 0.758, 0.861],
    "MAPE_SD": [0.0221, 0.0252, 0.0029, 0.0221, 0.0165],
    "RMSE_DC": [4.565, 4.677, 0.835, 4.565, 0.397],
    "R2_DC": [0.511, 0.487, 0.984, 0.511, 0.996],
    "MAPE_DC": [0.099, 0.100, 0.0166, 0.099, 0.0093],
    "RMSE_QF": [36.09, 77.81, 44.51, 36.71, 27.17],
    "R2_QF": [0.993, 0.968, 0.989, 0.993, 0.996],
    "MAPE_QF": [0.0044, 0.0098, 0.0052, 0.0043, 0.0032]
}
pzt_df = pd.DataFrame(pzt_data).set_index("Model")

# Define Titanate dataset performance
titanate_data = {
    "Model": ["BaselineNet", "DeepNormNet", "MultiHeadNet", "LightEnsemble", "FullEnsemble"],
    "RMSE_DC": [4.05, 5.18, 1.18, 1.98, 1.41],
    "R2_DC": [-5.32, -9.30, 0.46, -0.51, 0.23],
    "MAPE_DC": [0.016, 0.021, 0.0038, 0.0078, 0.0051],
    "RMSE_ER": [0.472, 0.450, 0.345, 0.453, 0.390],
    "R2_ER": [0.023, 0.113, 0.480, 0.102, 0.335],
    "MAPE_ER": [0.089, 0.084, 0.051, 0.085, 0.072],
    "RMSE_TCR": [0.453, 0.356, 0.336, 0.399, 0.364],
    "R2_TCR": [-0.014, 0.373, 0.443, 0.214, 0.346],
    "MAPE_TCR": [0.200, 0.132, 0.117, 0.173, 0.152],
    "RMSE_CT": [12.04, 16.32, 11.92, 12.02, 11.95],
    "R2_CT": [0.423, -0.060, 0.434, 0.425, 0.431],
    "MAPE_CT": [0.0187, 0.0267, 0.0176, 0.0181, 0.0178]
}
titanate_df = pd.DataFrame(titanate_data).set_index("Model")

pzt_metrics = [
    "RMSE_SD", "R2_SD", "MAPE_SD",
    "RMSE_DC", "R2_DC", "MAPE_DC",
    "RMSE_QF", "R2_QF", "MAPE_QF"
]

fig, axes = plt.subplots(3, 3, figsize=(18, 12))
axes = axes.flatten()
for i, metric in enumerate(pzt_metrics):
    pzt_df[metric].plot(kind='bar', ax=axes[i], color=origin_palette[i % len(origin_palette)])
    axes[i].set_title(f"PZT - {metric}", fontsize=11)
    axes[i].set_ylabel(metric)
    axes[i].grid(True, linestyle='--', alpha=0.5)
    axes[i].set_xticklabels(pzt_df.index, rotation=45)
fig.tight_layout()
fig.savefig("PZT_Full_Performance_OriginPro.png", dpi=300)

# Titanate metrics
titanate_metrics = [
    "RMSE_DC", "R2_DC", "MAPE_DC",
    "RMSE_ER", "R2_ER", "MAPE_ER",
    "RMSE_TCR", "R2_TCR", "MAPE_TCR",
    "RMSE_CT", "R2_CT", "MAPE_CT"
]
pdf = matplotlib.backends.backend_pdf.PdfPages("PZT_Titanate_Performance_OriginPro.pdf")

# --- Plot PZT Metrics ---
fig, axes = plt.subplots(3, 3, figsize=(18, 12))
axes = axes.flatten()
for i, metric in enumerate(pzt_metrics):
    pzt_df[metric].plot(kind='bar', ax=axes[i], color=origin_palette[i % len(origin_palette)])
    axes[i].set_title(f"PZT - {metric}", fontsize=11)
    axes[i].set_ylabel(metric)
    axes[i].grid(True, linestyle='--', alpha=0.5)
    axes[i].set_xticklabels(pzt_df.index, rotation=45)
fig.tight_layout()
pdf.savefig(fig)
plt.close(fig)

# --- Plot Titanate Metrics ---
fig, axes = plt.subplots(4, 3, figsize=(18, 16))
axes = axes.flatten()
for i, metric in enumerate(titanate_metrics):
    titanate_df[metric].plot(kind='bar', ax=axes[i], color=origin_palette[i % len(origin_palette)])
    axes[i].set_title(f"Titanate - {metric}", fontsize=11)
    axes[i].set_ylabel(metric)
    axes[i].grid(True, linestyle='--', alpha=0.5)
    axes[i].set_xticklabels(titanate_df.index, rotation=45)
# Remove unused subplots
for j in range(len(titanate_metrics), len(axes)):
    fig.delaxes(axes[j])
fig.tight_layout()
pdf.savefig(fig)
plt.close(fig)

# Finalize PDF
pdf.close()
print("Saved to PZT_Titanate_Performance_OriginPro.pdf")
