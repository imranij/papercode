# -*- coding: utf-8 -*-
"""
Created on Mon Jul 28 11:34:12 2025

@author: imran.imran
"""

import os
import pandas as pd
import numpy as np
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_percentage_error

# --- Setup Paths ---
DATA_DIR = "predictions"
output_dir = os.path.join(DATA_DIR, "predictiveanalysis")
os.makedirs(output_dir, exist_ok=True)

# --- Abbreviation Map ---
target_abbr = {
    "SinteredDensity": "SD",
    "DielectricConstant": "DC",
    "QualityFactor": "QF",
    "ElectricalResistivity": "ER",
    "TemperatureCoefficientOfResistivity": "TCR",
    "CurieTemperature": "CT"
}

# --- Target Definitions ---
pzt_targets = [("SinteredDensity", "SD"), ("DielectricConstant", "DC"), ("QualityFactor", "QF")]
tio3_targets = [
    ("DielectricConstant", "DC"),
    ("ElectricalResistivity", "ER"),
    ("TemperatureCoefficientOfResistivity", "TCR"),
    ("CurieTemperature", "CT")
]

# --- Load PZT Predictions and Actuals ---
pzt_actuals = pd.read_csv(os.path.join(DATA_DIR, "sample_pzt_actuals.csv"))
pzt_model_dfs = {
    "BaselineNet": pd.read_csv(os.path.join(DATA_DIR, "sample_pzt_predictions.csv")),
    "DeepNormNet": pd.read_csv(os.path.join(DATA_DIR, "sample_pzt_v2_predictions.csv")),
    "MultiHeadNet": pd.read_csv(os.path.join(DATA_DIR, "sample_pzt_v3_predictions.csv")),
    "LightEnsemble": pd.read_csv(os.path.join(DATA_DIR, "stacked_v12_pzt_predictions_v1v2.csv")),
    "FullEnsemble": pd.read_csv(os.path.join(DATA_DIR, "stacked_v123_pzt_predictions_v2.csv"))
}

# --- Load TIO3 Predictions and Actuals ---
tio3_actuals = pd.read_csv(os.path.join(DATA_DIR, "sample_tio3_actuals.csv"))
tio3_model_dfs = {
    "BaselineNet": pd.read_csv(os.path.join(DATA_DIR, "sample_tio3_predictions.csv")),
    "DeepNormNet": pd.read_csv(os.path.join(DATA_DIR, "sample_tio3_v2_predictions.csv")),
    "MultiHeadNet": pd.read_csv(os.path.join(DATA_DIR, "sample_tio3_v3_predictions.csv")),
    "LightEnsemble": pd.read_csv(os.path.join(DATA_DIR, "stacked_v12_tio3_predictions_v1v2.csv")),
    "FullEnsemble": pd.read_csv(os.path.join(DATA_DIR, "stacked_v123_tio3_predictions_v2.csv"))
}

# --- Compute Target-wise Summary Metrics ---
def compute_summary(model_dfs, actual_df, target_list):
    summary = {}
    for model_name, df in model_dfs.items():
        row = {}
        for target, abbr in target_list:
            y_true = actual_df[target].values
            y_pred = df[target].values
            row[f"RMSE_{abbr}"] = np.sqrt(mean_squared_error(y_true, y_pred))
            row[f"R2_{abbr}"] = r2_score(y_true, y_pred)
            row[f"MAPE_{abbr}"] = mean_absolute_percentage_error(y_true, y_pred)
        summary[model_name] = row
    return pd.DataFrame.from_dict(summary, orient='index')

# --- Compute Average Metrics ---
def compute_average(model_dfs, actual_df, target_list):
    rows = []
    for model_name, df in model_dfs.items():
        rmse, r2, mape = [], [], []
        for target, _ in target_list:
            y_true = actual_df[target].values
            y_pred = df[target].values
            rmse.append(np.sqrt(mean_squared_error(y_true, y_pred)))
            r2.append(r2_score(y_true, y_pred))
            mape.append(mean_absolute_percentage_error(y_true, y_pred))
        rows.append({
            "Model": model_name,
            "Avg_RMSE": np.mean(rmse),
            "Avg_R2": np.mean(r2),
            "Avg_MAPE": np.mean(mape)
        })
    return pd.DataFrame(rows)

# --- Generate Tables ---
pzt_summary_df = compute_summary(pzt_model_dfs, pzt_actuals, pzt_targets)
tio3_summary_df = compute_summary(tio3_model_dfs, tio3_actuals, tio3_targets)
pzt_avg_df = compute_average(pzt_model_dfs, pzt_actuals, pzt_targets)
tio3_avg_df = compute_average(tio3_model_dfs, tio3_actuals, tio3_targets)

# --- Save to CSV ---
pzt_summary_df.to_csv(os.path.join(output_dir, "PZT_Model_Summary_Metrics.csv"))
tio3_summary_df.to_csv(os.path.join(output_dir, "TIO3_Model_Summary_Metrics.csv"))
pzt_avg_df.to_csv(os.path.join(output_dir, "PZT_Model_Average_Metrics.csv"), index=False)
tio3_avg_df.to_csv(os.path.join(output_dir, "TIO3_Model_Average_Metrics.csv"), index=False)

print("✅ Saved all PZT and TiO₃ metric summaries and averages to:")
print("📄", os.path.join(output_dir, "PZT_Model_Summary_Metrics.csv"))
print("📄", os.path.join(output_dir, "TIO3_Model_Summary_Metrics.csv"))
print("📄", os.path.join(output_dir, "PZT_Model_Average_Metrics.csv"))
print("📄", os.path.join(output_dir, "TIO3_Model_Average_Metrics.csv"))
