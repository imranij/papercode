# -*- coding: utf-8 -*-
"""
Created on Mon Jul 28 10:10:29 2025
@author: imran.imran
"""

import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_percentage_error
import seaborn as sns

# --- Target abbreviation mapping ---
# Target abbreviation mapping
target_abbr = {
    "SinteredDensity": "Sintered Density",
    "DielectricConstant": "Dielectric Constant",
    "QualityFactor": "Quality Factor",
    "ElectricalResistivity": "Electrical Resistivity",
    "TemperatureCoefficientOfResistivity": "Temperature Coefficient of Resistivity",
    "CurieTemperature": "Curie Temperature"
}

# -----------
# target_abbr = {
    # "SinteredDensity": "SD",
    # "DielectricConstant": "DC",
    # "QualityFactor": "QF",
    # "ElectricalResistivity": "ER",
    # "TemperatureCoefficientOfResistivity": "TCR",
    # "CurieTemperature": "CT"
# }

# --- Setup Paths ---
DATA_DIR = "predictions"
output_dir = os.path.join(DATA_DIR, "predictiveanalysis")
os.makedirs(output_dir, exist_ok=True)

# --- Load PZT ---
actuals = pd.read_csv(os.path.join(DATA_DIR, "sample_pzt_actuals.csv"))
v1_preds = pd.read_csv(os.path.join(DATA_DIR, "sample_pzt_predictions.csv"))
v2_preds = pd.read_csv(os.path.join(DATA_DIR, "sample_pzt_v2_predictions.csv"))
v3_preds = pd.read_csv(os.path.join(DATA_DIR, "sample_pzt_v3_predictions.csv"))
stacked_v1v2 = pd.read_csv(os.path.join(DATA_DIR, "stacked_v12_pzt_predictions_v1v2.csv"))
stacked_v123 = pd.read_csv(os.path.join(DATA_DIR, "stacked_v123_pzt_predictions_v2.csv"))

model_dfs = {
    "Actual": actuals,
    "BaselineNet": v1_preds,
    "DeepNormNet": v2_preds,
    "MultiHeadNet": v3_preds,
    "LightEnsemble": stacked_v1v2,
    "FullEnsemble": stacked_v123
}

line_styles = ["solid", "dashed", "dotted", "dashdot", (0, (3, 1, 1, 1)), (0, (5, 2))]
line_widths = [2.5, 2, 2, 2, 2, 2]
sample_slice = slice(0, 150)
targets = actuals.columns.tolist()

# === 1. Line Charts ===
for target in targets:
    short = target_abbr.get(target, target)
    fig, ax = plt.subplots(figsize=(12, 5))
    for i, (model_name, df) in enumerate(model_dfs.items()):
        ax.plot(df[target].values[sample_slice], label=model_name,
                linestyle=line_styles[i % len(line_styles)],
                linewidth=line_widths[i % len(line_widths)])
    ax.set_title(f"PZT - Prediction Comparison for {short}", fontsize=14)
    ax.set_xlabel("Sample ID")
    ax.set_ylabel(short)
    ax.legend()
    ax.grid(True, linestyle='--', alpha=0.5)
    fig.tight_layout()
    fig.savefig(os.path.join(output_dir, f"PZT_Prediction_LineChart_{target}.pdf"))
    plt.close(fig)

# === 2. Residual Plots ===
models_to_plot = {k: v for k, v in model_dfs.items() if k != "Actual"}
for target in targets:
    short = target_abbr.get(target, target)
    fig, ax = plt.subplots(figsize=(12, 5))
    y_true = actuals[target].values
    for i, (model_name, df) in enumerate(models_to_plot.items()):
        y_pred = df[target].values
        residuals = y_true - y_pred
        ax.plot(residuals[sample_slice], label=model_name,
                linestyle=line_styles[i % len(line_styles)],
                linewidth=line_widths[i % len(line_widths)])
    ax.set_title(f"PZT - Residual Plot for {short} (Actual - Predicted)", fontsize=14)
    ax.set_xlabel("Sample ID")
    ax.set_ylabel("Residual")
    ax.axhline(0, color='black', linestyle='--', linewidth=1)
    ax.legend()
    ax.grid(True, linestyle='--', alpha=0.5)
    fig.tight_layout()
    fig.savefig(os.path.join(output_dir, f"PZT_Residual_{target}.pdf"))
    plt.close(fig)

# === 3. Combined Bar Chart ===
metrics = {"Model": [], "Target": [], "RMSE": [], "R2": [], "MAPE": []}
for model_name, df in model_dfs.items():
    if model_name == "Actual":
        continue
    for target in targets:
        y_true = actuals[target].values
        y_pred = df[target].values
        short = target_abbr.get(target, target)
        metrics["Model"].append(model_name)
        metrics["Target"].append(short)
        metrics["RMSE"].append(np.sqrt(mean_squared_error(y_true, y_pred)))
        metrics["R2"].append(r2_score(y_true, y_pred))
        metrics["MAPE"].append(mean_absolute_percentage_error(y_true, y_pred))

metric_df = pd.DataFrame(metrics)

fig, axes = plt.subplots(2, 2, figsize=(16, 10), gridspec_kw={'height_ratios': [1, 1.2]})
sns.set(style="whitegrid")

sns.barplot(data=metric_df, x="Target", y="RMSE", hue="Model", ax=axes[0, 0])
axes[0, 0].set_title("RMSE per Target")
axes[0, 0].set_ylabel("RMSE")
axes[0, 0].set_xlabel("")

sns.barplot(data=metric_df, x="Target", y="MAPE", hue="Model", ax=axes[0, 1])
axes[0, 1].set_title("MAPE per Target")
axes[0, 1].set_ylabel("MAPE")
axes[0, 1].set_xlabel("")

ax_r2 = fig.add_subplot(2, 1, 2)
sns.barplot(data=metric_df, x="Target", y="R2", hue="Model", ax=ax_r2)
ax_r2.set_title("R² per Target")
ax_r2.set_ylabel("R² Score")
ax_r2.set_xlabel("Target Property")

fig.tight_layout()
fig.savefig(os.path.join(output_dir, "PZT_Model_Metrics_BarCharts.pdf"))
plt.close(fig)

print(f"✅ All abbreviated visual outputs saved to: {output_dir}")



# -*- coding: utf-8 -*-
"""
Created on Mon Jul 28 10:10:29 2025
@author: imran.imran
"""
import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_percentage_error
import seaborn as sns

# --- Abbreviation mapping ---
target_abbr = {
    "SinteredDensity": "SD",
    "DielectricConstant": "DC",
    "QualityFactor": "QF",
    "ElectricalResistivity": "ER",
    "TemperatureCoefficientOfResistivity": "TCR",
    "CurieTemperature": "CT"
}

# --- Setup Paths ---
DATA_DIR = "predictions"
output_dir = os.path.join(DATA_DIR, "predictiveanalysis")
os.makedirs(output_dir, exist_ok=True)

# --- Load All Model Predictions and Actuals for TiO3 ---
actuals = pd.read_csv(os.path.join(DATA_DIR, "sample_tio3_actuals.csv"))
v1_preds = pd.read_csv(os.path.join(DATA_DIR, "sample_tio3_predictions.csv"))
v2_preds = pd.read_csv(os.path.join(DATA_DIR, "sample_tio3_v2_predictions.csv"))
v3_preds = pd.read_csv(os.path.join(DATA_DIR, "sample_tio3_v3_predictions.csv"))
stacked_v1v2 = pd.read_csv(os.path.join(DATA_DIR, "stacked_v12_tio3_predictions_v1v2.csv"))
stacked_v123 = pd.read_csv(os.path.join(DATA_DIR, "stacked_v123_tio3_predictions_v2.csv"))

# --- Assign model names and dataframes ---
model_dfs = {
    "Actual": actuals,
    "BaselineNet": v1_preds,
    "DeepNormNet": v2_preds,
    "MultiHeadNet": v3_preds,
    "LightEnsemble": stacked_v1v2,
    "FullEnsemble": stacked_v123
}

# --- Plot Settings ---
line_styles = ["solid", "dashed", "dotted", "dashdot", (0, (3, 1, 1, 1)), (0, (5, 2))]
line_widths = [2.5, 2, 2, 2, 2, 2]
sample_slice = slice(0, 150)
targets = actuals.columns.tolist()

# === 1. Line Charts ===
for target in targets:
    short = target_abbr.get(target, target)
    fig, ax = plt.subplots(figsize=(12, 5))
    for i, (model_name, df) in enumerate(model_dfs.items()):
        ax.plot(df[target].values[sample_slice], label=model_name,
                linestyle=line_styles[i % len(line_styles)],
                linewidth=line_widths[i % len(line_widths)])
    ax.set_title(f"TiO₃ - Prediction Comparison for {short}", fontsize=14)
    ax.set_xlabel("Sample ID")
    ax.set_ylabel(short)
    ax.legend()
    ax.grid(True, linestyle='--', alpha=0.5)
    fig.tight_layout()
    fig.savefig(os.path.join(output_dir, f"TIO3_Prediction_LineChart_{target}.pdf"))
    plt.close(fig)

# === 2. Residual Plots ===
models_to_plot = {k: v for k, v in model_dfs.items() if k != "Actual"}
for target in targets:
    short = target_abbr.get(target, target)
    fig, ax = plt.subplots(figsize=(12, 5))
    y_true = actuals[target].values
    for i, (model_name, df) in enumerate(models_to_plot.items()):
        y_pred = df[target].values
        residuals = y_true - y_pred
        ax.plot(residuals[sample_slice], label=model_name,
                linestyle=line_styles[i % len(line_styles)],
                linewidth=line_widths[i % len(line_widths)])
    ax.set_title(f"TiO₃ - Residual Plot for {short} (Actual - Predicted)", fontsize=14)
    ax.set_xlabel("Sample ID")
    ax.set_ylabel("Residual")
    ax.axhline(0, color='black', linestyle='--', linewidth=1)
    ax.legend()
    ax.grid(True, linestyle='--', alpha=0.5)
    fig.tight_layout()
    fig.savefig(os.path.join(output_dir, f"TIO3_Residual_{target}.pdf"))
    plt.close(fig)

# === 3. Combined Bar Chart ===
metrics = {"Model": [], "Target": [], "RMSE": [], "R2": [], "MAPE": []}
for model_name, df in model_dfs.items():
    if model_name == "Actual":
        continue
    for target in targets:
        y_true = actuals[target].values
        y_pred = df[target].values
        short = target_abbr.get(target, target)
        metrics["Model"].append(model_name)
        metrics["Target"].append(short)
        metrics["RMSE"].append(np.sqrt(mean_squared_error(y_true, y_pred)))
        metrics["R2"].append(r2_score(y_true, y_pred))
        metrics["MAPE"].append(mean_absolute_percentage_error(y_true, y_pred))

metric_df = pd.DataFrame(metrics)

# Plot into a single combined figure
fig, axes = plt.subplots(2, 2, figsize=(16, 10), gridspec_kw={'height_ratios': [1, 1.2]})
sns.set(style="whitegrid")

sns.barplot(data=metric_df, x="Target", y="RMSE", hue="Model", ax=axes[0, 0])
axes[0, 0].set_title("RMSE per Target")
axes[0, 0].set_ylabel("RMSE")
axes[0, 0].set_xlabel("")

sns.barplot(data=metric_df, x="Target", y="MAPE", hue="Model", ax=axes[0, 1])
axes[0, 1].set_title("MAPE per Target")
axes[0, 1].set_ylabel("MAPE")
axes[0, 1].set_xlabel("")

ax_r2 = fig.add_subplot(2, 1, 2)
sns.barplot(data=metric_df, x="Target", y="R2", hue="Model", ax=ax_r2)
ax_r2.set_title("R² per Target")
ax_r2.set_ylabel("R² Score")
ax_r2.set_xlabel("Target Property")

fig.tight_layout()
fig.savefig(os.path.join(output_dir, "TIO3_Model_Metrics_BarCharts.pdf"))
plt.close(fig)

print(f"✅ All TiO₃ visual outputs saved with abbreviated target names in: {output_dir}")

