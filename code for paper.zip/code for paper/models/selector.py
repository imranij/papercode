import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler

def select_top_configurations(X_input, Y_pred, input_cols, output_cols, top_k=3):
    """
    Selects top-k configurations based on Euclidean distance from centroid in normalized output space.

    Parameters:
        X_input (DataFrame): Scaled input features (X)
        Y_pred (np.ndarray): Predicted output performance (Y)
        input_cols (list): Names of input features
        output_cols (list): Names of predicted performance columns
        top_k (int): Number of top recommendations to return

    Returns:
        List of top-k recommended configurations with predicted performance scores.
    """
    # Normalize the predicted outputs
    scaler = MinMaxScaler()
    Y_norm = scaler.fit_transform(Y_pred)

    # Compute centroid of normalized Y
    centroid = np.mean(Y_norm, axis=0)

    # Compute Euclidean distance from centroid
    distances = np.linalg.norm(Y_norm - centroid, axis=1)

    # Get indices of top_k farthest points (assumed optimal)
    top_indices = np.argsort(distances)[-top_k:][::-1]

    results = []
    for idx in top_indices:
        config = dict(zip(input_cols, X_input.iloc[idx].values))
        prediction = dict(zip(output_cols, Y_pred[idx].round(4)))
        results.append({
            "rank": len(results) + 1,
            "inputs": config,
            "predicted_outputs": prediction
        })

    return results
