# models/pytorch_model.py
import torch.nn as nn

class PZTNet(nn.Module):
    def __init__(self):
        super(PZTNet, self).__init__()
        self.fc = nn.Sequential(
            nn.Linear(7, 64),
            nn.ReLU(),
            nn.Linear(64, 128),
            nn.ReLU(),
            nn.Linear(128, 64),
            nn.ReLU(),
            nn.Linear(64, 3)  # Outputs: SinteredDensity, DielectricConstant, QF
        )

    def forward(self, x):
        return self.fc(x)
class TiO3Net(nn.Module):
    def __init__(self):
        super(TiO3Net, self).__init__()
        self.fc = nn.Sequential(
            nn.Linear(8, 64),
            nn.ReLU(),
            nn.Linear(64, 128),
            nn.ReLU(),
            nn.Linear(128, 64),
            nn.ReLU(),
            nn.Linear(64, 4)
        )

    def forward(self, x):
        return self.fc(x)
